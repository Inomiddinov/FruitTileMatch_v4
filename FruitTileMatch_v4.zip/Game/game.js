(() => {
  "use strict";

  // =========================================================================
  // THEMES CONFIGURATION
  // =========================================================================
  const THEMES = {
    fruits: {
      id: "fruits",
      name: "Fresh Fruits",
      icon: "🍓",
      bgGradient: ["#f2fbf7", "#d8f5e7"],
      accentColor: "#2ecc71",
      cardBg: "#ffffff",
      tileBorder: "#c6ebd7",
      tiles: ["🍎", "🍌", "🍇", "🍓", "🥝", "🍊", "🍐", "🍒", "🥑", "🍍", "🫐", "🍉"],
      unlocked: true,
      price: 0
    },
    sweets: {
      id: "sweets",
      name: "Sweet Bakery",
      icon: "🧁",
      bgGradient: ["#fff4f8", "#ffdce8"],
      accentColor: "#ff5e97",
      cardBg: "#ffffff",
      tileBorder: "#fed0e0",
      tiles: ["🍰", "🍩", "🍦", "🍭", "🧁", "🍫", "🍪", "🥞", "🍬", "🍮", "🥐", "🎂"],
      unlocked: false,
      price: 250
    },
    gems: {
      id: "gems",
      name: "Magic Gems",
      icon: "💎",
      bgGradient: ["#f3f2ff", "#ddd8ff"],
      accentColor: "#7950f2",
      cardBg: "#ffffff",
      tileBorder: "#d1c9ff",
      tiles: ["💎", "💍", "🔮", "⭐", "👑", "🪙", "🪄", "🌟", "🏵️", "💫", "✨", "💠"],
      unlocked: false,
      price: 500
    },
    animals: {
      id: "animals",
      name: "Cute Pets",
      icon: "🐱",
      bgGradient: ["#fff8ef", "#ffe8cc"],
      accentColor: "#ff922b",
      cardBg: "#ffffff",
      tileBorder: "#ffdda6",
      tiles: ["🐱", "🐶", "🐰", "🐼", "🦊", "🐻", "🐨", "🐯", "🦁", "🐸", "🐵", "🦄"],
      unlocked: false,
      price: 750
    },
    space: {
      id: "space",
      name: "Galaxy Quest",
      uzName: "Fazoviy Sayohat",
      ruName: "Космос",
      icon: "🚀",
      bgGradient: ["#0f172a", "#1e1b4b"],
      accentColor: "#38bdf8",
      cardBg: "#1e293b",
      tileBorder: "#334155",
      tiles: ["🚀", "🪐", "⭐", "🛸", "👨‍🚀", "👾", "☄️", "🌕", "🌌", "🛰️", "🌠", "🔮"],
      unlocked: false,
      price: 900
    }
  };

  const ACCENT_COLORS = ["#ff7990", "#ffc857", "#b58af6", "#ff8ab0", "#78c99a", "#ffad62", "#4dabf7"];

  // =========================================================================
  // LOCALIZATION (UZ, EN, RU, TR)
  // =========================================================================
  const COPY = {
    en: {
      title: "Fruit Tile Match",
      play: "PLAY",
      levels: "LEVELS",
      themes: "THEMES",
      dailyReward: "REWARDS",
      settings: "SETTINGS",
      back: "BACK",
      streak: "day streak",
      streakKeep: "Play today to keep your streak!",
      streakNext: "Come back tomorrow to grow it!",
      tutorialTap: "Tap 3 matching tiles!",
      tutorialMore: "Great! Pick another match!",
      tray: "MATCH TRAY",
      level: "LEVEL",
      score: "SCORE",
      coins: "COINS",
      best: "BEST",
      pause: "Paused",
      resume: "Resume",
      restart: "Restart",
      home: "Home",
      gameOver: "Tray is full!",
      tryAgain: "Try Again",
      boardCleared: "Level Cleared!",
      nextLevel: "Next Level",
      undo: "Undo",
      shuffle: "Shuffle",
      hint: "Hint",
      magic: "Magic",
      select: "SELECT",
      selected: "SELECTED",
      unlock: "UNLOCK",
      claim: "CLAIM",
      claimed: "CLAIMED",
      day: "Day",
      dailyTitle: "Daily Rewards",
      sound: "Sound SFX",
      music: "Music BGM",
      needCoins: "Not enough coins!",
      noMoves: "No tiles to undo!",
      hintFound: "Hint: Matching tiles highlighted!",
      shuffled: "Tiles shuffled!",
      magicUsed: "Magic cleared a set!",
      revive: "Revive (Clear 3)",
      watchAd: "Watch Ad",
      extraChance: "Extra Chance",
      freeHint: "Free Hint",
      freeShuffle: "Free Shuffle",
      freeBoosters: "Free Boosters",
      adUnavailable: "Ad is not available right now. Please try again later.",
      adClosedEarly: "Ad was closed early. No reward granted.",
      adLoading: "Loading ad...",
      rewardReceivedHint: "Reward received: +1 Hint!",
      rewardReceivedShuffle: "Reward received: +1 Shuffle!",
      rewardReceivedChance: "Extra chance granted! 3 tiles cleared.",
      comboGood: "GOOD!",
      comboGreat: "GREAT!",
      comboAwesome: "AWESOME!",
      comboSuper: "SUPER FEVER! 🔥",
      goldenBonus: "+20 🪙 Gold Bonus! ✨",
      language: "Language",
      layoutNames: {
        pyramid: "Pyramid",
        butterfly: "Butterfly",
        castle: "Castle",
        diamond: "Diamond",
        star: "Star",
        flower: "Lotus",
        heart: "Heart",
        labyrinth: "Labyrinth"
      }
    },
    uz: {
      title: "Fruit Tile Match",
      play: "O'YNASH",
      levels: "BOSQICHLAR",
      themes: "TEMALAR",
      dailyReward: "MUKOFOTLAR",
      settings: "SOZLAMALAR",
      back: "ORQAGA",
      streak: "kunlik seriya",
      streakKeep: "Seriyani saqlash uchun bugun o'ynang!",
      streakNext: "Ertaga yana keling, seriya o'sadi!",
      tutorialTap: "Bir xil 3 ta mevani tanlang!",
      tutorialMore: "Yana bir xil mevani tanlang!",
      tray: "YIG'ISH PATNISI",
      level: "BOSQICH",
      score: "OCHKO",
      coins: "TANGA",
      best: "ENG YAXSHI",
      pause: "Pauza",
      resume: "Davom etish",
      restart: "Qayta boshlash",
      home: "Bosh sahifa",
      gameOver: "Patnis to'ldi! Mag'lubiyat",
      tryAgain: "Qayta urinish",
      boardCleared: "G'alaba! Bosqich o'tildi! 🎉",
      nextLevel: "Keyingi bosqich",
      undo: "Qaytarish",
      shuffle: "Aralashtirish",
      hint: "Yordam",
      magic: "Sehr",
      select: "TANLASH",
      selected: "TANLANGAN",
      unlock: "OCHISH",
      claim: "OLISH",
      claimed: "OLINGAN",
      day: "Kun",
      dailyTitle: "Kunlik Mukofotlar",
      sound: "Ovoz",
      music: "Musiqa",
      needCoins: "Tangalar yetarli emas!",
      noMoves: "Qaytarish uchun kafel yo'q!",
      hintFound: "Yordam: Mos kafellar ko'rsatildi!",
      shuffled: "Kafellar aralashtirildi!",
      magicUsed: "Sehr orqali 3 ta kafel olib tashlandi!",
      revive: "Qutqarish (3 ta tozalash)",
      watchAd: "Reklama ko'rish",
      extraChance: "Qo'shimcha imkon",
      freeHint: "Bepul yordam",
      freeShuffle: "Bepul aralashtirish",
      freeBoosters: "Bepul kuchaytirgichlar",
      adUnavailable: "Reklama hozircha mavjud emas. Birozdan so'ng urinib ko'ring.",
      adClosedEarly: "Reklama erta yopildi. Mukofot berilmadi.",
      adLoading: "Reklama yuklanmoqda...",
      rewardReceivedHint: "Mukofot olindi: +1 Yordam!",
      rewardReceivedShuffle: "Mukofot olindi: +1 Aralashtirish!",
      rewardReceivedChance: "Qo'shimcha imkon berildi! 3 ta kafel tozalandi.",
      comboGood: "YAXSHI!",
      comboGreat: "AJOYIB!",
      comboAwesome: "DAHSHAT!",
      comboSuper: "SUPER FEVER! 🔥",
      goldenBonus: "+20 🪙 Oltin bonus! ✨",
      language: "Til",
      layoutNames: {
        pyramid: "Piramida",
        butterfly: "Kapalak",
        castle: "Qasr",
        diamond: "Olmos",
        star: "Yulduz",
        flower: "Nilufar",
        heart: "Yurak",
        labyrinth: "Labirint"
      }
    },
    ru: {
      title: "Fruit Tile Match",
      play: "ИГРАТЬ",
      levels: "УРОВНИ",
      themes: "ТЕМЫ",
      dailyReward: "НАГРАДЫ",
      settings: "НАСТРОЙКИ",
      back: "НАЗАД",
      streak: "дн. подряд",
      streakKeep: "Сыграйте сегодня, чтобы сохранить серию!",
      streakNext: "Возвращайтесь завтра, серия растёт!",
      tutorialTap: "Выберите 3 одинаковых плитки!",
      tutorialMore: "Отлично! Выберите ещё такую же!",
      tray: "ЛОТОК",
      level: "УРОВЕНЬ",
      score: "СЧЕТ",
      coins: "МОНЕТЫ",
      best: "ЛУЧШИЙ",
      pause: "Пауза",
      resume: "Продолжить",
      restart: "Заново",
      home: "В меню",
      gameOver: "Лоток заполнен!",
      tryAgain: "Еще раз",
      boardCleared: "Уровень пройден!",
      nextLevel: "Следующий",
      undo: "Отмена",
      shuffle: "Перемешать",
      hint: "Подсказка",
      magic: "Магия",
      select: "ВЫБРАТЬ",
      selected: "ВЫБРАНО",
      unlock: "ОТКРЫТЬ",
      claim: "ЗАБРАТЬ",
      claimed: "ПОЛУЧЕНО",
      day: "День",
      dailyTitle: "Ежедневные награды",
      sound: "Звуковые эффекты",
      music: "Музыка",
      needCoins: "Недостаточно монет!",
      noMoves: "Нечего возвращать!",
      hintFound: "Подсказка: совпадения подсвечены!",
      shuffled: "Плитки перемешаны!",
      magicUsed: "Магия убрала тройку!",
      revive: "Спастись (убрать 3)",
      watchAd: "Смотреть рекламу",
      extraChance: "Второй шанс",
      freeHint: "Бесплатная подсказка",
      freeShuffle: "Бесплатное перемешивание",
      freeBoosters: "Бесплатные бустеры",
      adUnavailable: "Реклама сейчас недоступна. Попробуйте позже.",
      adClosedEarly: "Реклама закрыта раньше времени. Награда не начислена.",
      adLoading: "Загрузка рекламы...",
      rewardReceivedHint: "Награда получена: +1 Подсказка!",
      rewardReceivedShuffle: "Награда получена: +1 Перемешивание!",
      rewardReceivedChance: "Второй шанс получен! 3 плитки убрано."
    },
    tr: {
      title: "Fruit Tile Match",
      play: "OYNA",
      levels: "SEVİYELER",
      themes: "TEMALAR",
      dailyReward: "ÖDÜLLER",
      settings: "AYARLAR",
      back: "GERİ",
      streak: "günlük seri",
      streakKeep: "Seriyi korumak için bugün oyna!",
      streakNext: "Yarın tekrar gel, serin büyüsün!",
      tutorialTap: "3 aynı karoyu seç!",
      tutorialMore: "Harika! Bir tane daha seç!",
      tray: "TEPSİ",
      level: "SEVİYE",
      score: "PUAN",
      coins: "ALTIN",
      best: "EN İYİ",
      pause: "Duraklatıldı",
      resume: "Sürdür",
      restart: "Yeniden",
      home: "Ana Menü",
      gameOver: "Tepsi Doldu!",
      tryAgain: "Tekrar Dene",
      boardCleared: "Bölüm Tamamlandı!",
      nextLevel: "Sonraki Bölüm",
      undo: "Geri Al",
      shuffle: "Karıştır",
      hint: "İpucu",
      magic: "Sihir",
      select: "SEÇ",
      selected: "SEÇİLDİ",
      unlock: "AÇ",
      claim: "AL",
      claimed: "ALINDI",
      day: "Gün",
      dailyTitle: "Günlük Ödüller",
      sound: "Ses Efektleri",
      music: "Müzik",
      needCoins: "Yetersiz altın!",
      noMoves: "Geri alınacak taş yok!",
      hintFound: "İpucu: Eşleşen taşlar parlatıldı!",
      shuffled: "Taşlar karıştırıldı!",
      magicUsed: "Sihir 3 taşı yok etti!",
      revive: "Kurtul (3 taş temizle)",
      watchAd: "Reklam İzle",
      extraChance: "Ekstra Şans",
      freeHint: "Ücretsiz İpucu",
      freeShuffle: "Ücretsiz Karıştırma",
      freeBoosters: "Ücretsiz Güçlendiriciler",
      adUnavailable: "Reklam şu anda mevcut değil. Lütfen daha sonra tekrar deneyin.",
      adClosedEarly: "Reklam erken kapatıldı. Ödül verilmedi.",
      adLoading: "Reklam yükleniyor...",
      rewardReceivedHint: "Ödül alındı: +1 İpucu!",
      rewardReceivedShuffle: "Ödül alındı: +1 Karıştırma!",
      rewardReceivedChance: "Ekstra şans verildi! 3 taş temizlendi."
    }
  };

  // =========================================================================
  // SETUP CANVAS & DEPENDENCIES
  // =========================================================================
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d", { alpha: false });
  const rawLang = String(window.fruitTileDependencies?.language || navigator.language || "uz").toLowerCase().slice(0, 2);
  const savedProgress = window.fruitTileDependencies?.progress || {};
  let currentLang = savedProgress.language || (rawLang === "ru" ? "ru" : "uz");
  let copy = COPY[currentLang] || COPY.uz || COPY.en;

  let messageTimeout = null;
  let audioContext = null;
  let animationFrame = null;
  let lastAnimationFrameTime = null;
  let bgmOscillators = [];
  let bgmNextNoteTime = 0;
  let bgmStep = 0;

  // =========================================================================
  // STATE MANAGEMENT
  // =========================================================================
  const state = {
    screen: "MENU", // "MENU" | "LEVEL_SELECT" | "GAME" | "THEMES" | "DAILY_REWARDS"
    level: Math.max(1, Math.floor(validNumber(savedProgress.level, 1))),
    score: validNumber(savedProgress.score, 0),
    bestScore: validNumber(savedProgress.bestScore, 0),
    coins: validNumber(savedProgress.coins, 150),
    currentTheme: savedProgress.currentTheme && THEMES[savedProgress.currentTheme] ? savedProgress.currentTheme : "fruits",
    unlockedThemes: savedProgress.unlockedThemes || ["fruits"],

    // Powerups counts
    powerups: {
      undo: validNumber(savedProgress.powerups?.undo, 3),
      shuffle: validNumber(savedProgress.powerups?.shuffle, 3),
      hint: validNumber(savedProgress.powerups?.hint, 3),
      magic: validNumber(savedProgress.powerups?.magic, 2)
    },

    // Levels progress { [levelNum]: { stars: 1..3, score: number } }
    levelsProgress: savedProgress.levelsProgress || { 1: { stars: 0, score: 0 } },
    levelPage: 0,

    // Daily rewards
    dailyReward: {
      lastClaimDate: savedProgress.dailyReward?.lastClaimDate || null,
      day: validNumber(savedProgress.dailyReward?.day, 0)
    },

    // First-time tutorial (hand pointer on level 1)
    tutorialDone: savedProgress.tutorialDone === true || validNumber(savedProgress.level, 1) > 1,
    lossesSinceAd: 0,

    // Daily play streak (consecutive days with at least one level started)
    streak: {
      count: validNumber(savedProgress.streak?.count, 0),
      best: validNumber(savedProgress.streak?.best, 0),
      lastDate: savedProgress.streak?.lastDate || null
    },

    // Audio preferences
    soundEnabled: savedProgress.soundEnabled !== false,
    musicEnabled: savedProgress.musicEnabled !== false,
    platformAudioEnabled: true,

    // Board gameplay
    tiles: [],
    tray: [],
    animations: [],
    undoStack: [],
    hintHighlights: new Set(),
    hintTimeout: null,
    comboMultiplier: 1,
    lastMatchAt: null,
    focusId: null,
    language: currentLang,
    screenShake: 0,
    layoutName: "",
    message: copy.title,
    messageUntil: 0,
    ended: false,
    won: false,
    starsEarned: 0,

    // Pausing
    manualPaused: false,
    platformPaused: false,
    adPaused: false,
    documentPaused: document.visibilityState !== "visible",

    // Advertising tracking
    levelsCompletedSinceAd: Math.max(0, Math.floor(validNumber(savedProgress.levelsCompletedSinceAd, 0))),
    adInProgress: false,
    boosterModal: null,

    // Layout
    layout: null,
    width: 0,
    height: 0,
    pixelRatio: 1,
    saveProgress: window.fruitTileDependencies?.saveProgress || (() => {})
  };

  function validNumber(val, fallback) {
    return Number.isFinite(Number(val)) ? Number(val) : fallback;
  }

  function isPaused() {
    return state.manualPaused || state.platformPaused || state.adPaused || state.documentPaused;
  }

  function setLanguage(lang) {
    if (!COPY[lang]) return;
    state.language = lang;
    currentLang = lang;
    copy = COPY[lang] || COPY.uz || COPY.en;
    state.message = copy.title;
    if (state.screen === "GAME" && state.level) {
      const cfg = getLevelConfig(state.level);
      const names = copy.layoutNames || {};
      state.layoutName = names[cfg.layoutType] || cfg.layoutType;
    }
    saveState();
    draw();
  }

  // =========================================================================
  // PERSISTENCE
  // =========================================================================
  function saveState() {
    const data = {
      level: state.level,
      score: state.score,
      bestScore: state.bestScore,
      coins: state.coins,
      currentTheme: state.currentTheme,
      unlockedThemes: state.unlockedThemes,
      powerups: state.powerups,
      levelsProgress: state.levelsProgress,
      levelsCompletedSinceAd: state.levelsCompletedSinceAd,
      dailyReward: state.dailyReward,
      streak: state.streak,
      tutorialDone: state.tutorialDone,
      soundEnabled: state.soundEnabled,
      musicEnabled: state.musicEnabled,
      language: state.language
    };
    Promise.resolve(state.saveProgress(data)).catch(err => {
      console.warn("[Fruit Tile Match] Save failed:", err);
    });
  }

  // =========================================================================
  // AUDIO ENGINE (SFX + Procedural Chords BGM)
  // =========================================================================
  function initAudioContext() {
    if (!audioContext) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) audioContext = new AudioCtx();
    }
    if (audioContext && audioContext.state === "suspended") {
      audioContext.resume().catch(() => {});
    }
  }

  function playSound(type) {
    if (!state.soundEnabled || !state.platformAudioEnabled) return;
    initAudioContext();
    if (!audioContext) return;

    try {
      const now = audioContext.currentTime;
      if (type === "tap") {
        playTone(520, now, 0.05, 0.04, "sine");
      } else if (type === "match") {
        playTone(523.25, now, 0.08, 0.05, "sine");
        playTone(659.25, now + 0.06, 0.08, 0.05, "sine");
        playTone(783.99, now + 0.12, 0.12, 0.06, "sine");
      } else if (type === "combo") {
        const mult = Math.min(5, Math.max(2, state.comboMultiplier));
        const root = 523.25 * Math.pow(1.12, mult - 1);
        playTone(root, now, 0.08, 0.06, "triangle");
        playTone(root * 1.25, now + 0.06, 0.08, 0.07, "triangle");
        playTone(root * 1.5, now + 0.12, 0.14, 0.08, "sine");
      } else if (type === "gold") {
        playTone(987.77, now, 0.06, 0.07, "sine");
        playTone(1318.51, now + 0.05, 0.08, 0.08, "triangle");
        playTone(1567.98, now + 0.11, 0.16, 0.08, "sine");
      } else if (type === "powerup") {
        playSweep(440, 880, now, 0.22, 0.06);
      } else if (type === "win") {
        playTone(523, now, 0.12, 0.06, "sine");
        playTone(659, now + 0.1, 0.12, 0.06, "sine");
        playTone(784, now + 0.2, 0.12, 0.06, "sine");
        playTone(1046, now + 0.3, 0.25, 0.07, "triangle");
      } else if (type === "lose") {
        playTone(392, now, 0.14, 0.05, "triangle");
        playTone(330, now + 0.1, 0.14, 0.05, "triangle");
        playTone(262, now + 0.2, 0.22, 0.06, "sawtooth");
      } else if (type === "coin") {
        playTone(987.77, now, 0.06, 0.05, "sine");
        playTone(1318.51, now + 0.06, 0.14, 0.05, "sine");
      } else if (type === "star") {
        playTone(880, now, 0.1, 0.05, "triangle");
        playTone(1174.66, now + 0.08, 0.18, 0.06, "sine");
      } else if (type === "error") {
        playTone(220, now, 0.09, 0.05, "square");
        playTone(180, now + 0.08, 0.12, 0.05, "square");
      }
    } catch (e) {
      // Ignore audio interruptions
    }
  }

  function playTone(freq, start, duration, volume, waveType) {
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.type = waveType || "sine";
    osc.frequency.setValueAtTime(freq, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.linearRampToValueAtTime(volume, start + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(audioContext.destination);
    osc.start(start);
    osc.stop(start + duration);
  }

  function playSweep(fStart, fEnd, start, duration, volume) {
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(fStart, start);
    osc.frequency.exponentialRampToValueAtTime(fEnd, start + duration);
    gain.gain.setValueAtTime(0.001, start);
    gain.gain.linearRampToValueAtTime(volume, start + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(audioContext.destination);
    osc.start(start);
    osc.stop(start + duration);
  }

  // Gentle procedural ambient music
  function updateBGM() {
    if (!state.musicEnabled || !state.platformAudioEnabled || isPaused()) return;
    initAudioContext();
    if (!audioContext) return;

    const now = audioContext.currentTime;
    if (now >= bgmNextNoteTime) {
      // Chill pentatonic chord progression: Cmaj9 - Am7 - Fmaj7 - Gsus4
      const chords = [
        [261.63, 329.63, 392.00, 493.88], // C E G B
        [220.00, 261.63, 329.63, 392.00], // A C E G
        [174.61, 220.00, 261.63, 329.63], // F A C E
        [196.00, 261.63, 293.66, 392.00]  // G C D G
      ];
      const chord = chords[bgmStep % chords.length];
      bgmStep += 1;

      chord.forEach((freq, i) => {
        const osc = audioContext.createOscillator();
        const gain = audioContext.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        const noteStart = now + i * 0.08;
        const noteLen = 2.4;
        gain.gain.setValueAtTime(0.0001, noteStart);
        gain.gain.linearRampToValueAtTime(0.015, noteStart + 0.3);
        gain.gain.exponentialRampToValueAtTime(0.0001, noteStart + noteLen);
        osc.connect(gain);
        gain.connect(audioContext.destination);
        osc.start(noteStart);
        osc.stop(noteStart + noteLen);
      });

      bgmNextNoteTime = now + 2.8;
    }
  }

  // =========================================================================
  // DAILY REWARDS SYSTEM
  // =========================================================================
  const DAILY_REWARDS_TABLE = [
    { day: 1, coins: 50, powerup: null, label: "50 🪙" },
    { day: 2, coins: 60, powerup: "undo", label: "60 🪙 + 1 ↩" },
    { day: 3, coins: 100, powerup: null, label: "100 🪙" },
    { day: 4, coins: 80, powerup: "shuffle", label: "80 🪙 + 1 🔀" },
    { day: 5, coins: 150, powerup: null, label: "150 🪙" },
    { day: 6, coins: 100, powerup: "hint", label: "100 🪙 + 1 💡" },
    { day: 7, coins: 300, powerup: "magic", label: "300 🪙 + 2 ✨" }
  ];

  function getDailyRewardStatus() {
    const today = new Date().toISOString().slice(0, 10);
    const lastClaim = state.dailyReward.lastClaimDate;
    if (!lastClaim) {
      return { canClaim: true, nextDayIndex: 0 };
    }
    if (lastClaim === today) {
      return { canClaim: false, nextDayIndex: state.dailyReward.day % 7 };
    }
    // Check if yesterday or older
    const lastDate = new Date(lastClaim);
    const currentDate = new Date(today);
    const diffDays = Math.round((currentDate - lastDate) / (1000 * 60 * 60 * 24));
    if (diffDays === 1) {
      return { canClaim: true, nextDayIndex: state.dailyReward.day % 7 };
    } else {
      // Missed a day -> reset to day 1
      return { canClaim: true, nextDayIndex: 0 };
    }
  }

  function claimDailyReward() {
    const status = getDailyRewardStatus();
    if (!status.canClaim) return false;

    const rewardIndex = status.nextDayIndex;
    const reward = DAILY_REWARDS_TABLE[rewardIndex];
    state.coins += reward.coins;
    if (reward.powerup) {
      const qty = reward.powerup === "magic" ? 2 : 1;
      state.powerups[reward.powerup] += qty;
    }
    state.dailyReward.lastClaimDate = new Date().toISOString().slice(0, 10);
    state.dailyReward.day = (rewardIndex + 1);

    playSound("coin");
    showMessage(`+${reward.coins} Coins! ${reward.label}`);
    saveState();
    return true;
  }

  // =========================================================================
  // LEVEL GENERATION & SOLVABILITY
  // =========================================================================
  const LAYOUT_TYPES = ["pyramid", "butterfly", "castle", "diamond", "star", "flower", "heart", "labyrinth"];

  function getLevelConfig(level) {
    const layoutIndex = (level - 1) % LAYOUT_TYPES.length;
    const layoutType = LAYOUT_TYPES[layoutIndex];

    // Early levels are a bit bigger so a session lasts longer (target: 5 min average)
    let tileCount = 33;
    let fruitVariety = 4;
    if (level === 2) {
      tileCount = 42;
      fruitVariety = 5;
    } else if (level === 3) {
      tileCount = 51;
      fruitVariety = 6;
    } else if (level === 4) {
      tileCount = 57;
      fruitVariety = 7;
    } else if (level === 5) {
      tileCount = 60;
      fruitVariety = 8;
    } else if (level >= 6) {
      tileCount = Math.min(72, 60 + Math.floor((level - 5) / 2) * 6);
      fruitVariety = Math.min(12, 7 + Math.floor(level / 3));
    }
    return { tileCount, fruitVariety, layoutType };
  }

  function getLayoutPositions(pattern, targetCount) {
    const positions = [];
    if (pattern === "pyramid") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          positions.push({ col: c, row: r, layer: 0, priority: Math.max(Math.abs(c-3), Math.abs(r-3)) });
        }
      }
      for (let r = 1; r <= 5; r++) {
        for (let c = 1; c <= 5; c++) {
          positions.push({ col: c, row: r, layer: 1, priority: Math.max(Math.abs(c-3), Math.abs(r-3)) - 2 });
        }
      }
      for (let r = 2; r <= 4; r++) {
        for (let c = 2; c <= 4; c++) {
          positions.push({ col: c, row: r, layer: 2, priority: Math.max(Math.abs(c-3), Math.abs(r-3)) - 4 });
        }
      }
      positions.push({ col: 3, row: 3, layer: 3, priority: -8 });
    } else if (pattern === "butterfly") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          if (c !== 3) {
            positions.push({ col: c, row: r, layer: 0, priority: Math.abs(r-3) + Math.abs(c-3) });
          } else {
            positions.push({ col: c, row: r, layer: 0, priority: Math.abs(r-3) * 0.5 });
          }
        }
      }
      for (const r of [1, 2, 4, 5]) {
        for (const c of [1, 2, 4, 5]) {
          positions.push({ col: c, row: r, layer: 1, priority: -2 });
        }
      }
      for (const r of [2, 4]) {
        for (const c of [1.5, 4.5]) {
          positions.push({ col: c, row: r, layer: 2, priority: -4 });
        }
      }
      for (let r = 2; r <= 4; r++) {
        positions.push({ col: 3, row: r, layer: 1, priority: -3 });
        positions.push({ col: 3, row: r, layer: 2, priority: -5 });
      }
    } else if (pattern === "castle") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          const isTower = (c <= 2 || c >= 4) && (r <= 2 || r >= 4);
          const isWall = (c >= 2 && c <= 4) || (r >= 2 && r <= 4);
          if (isTower || isWall) {
            positions.push({ col: c, row: r, layer: 0, priority: isTower ? 0 : 2 });
          }
        }
      }
      [[1,1], [5,1], [1,5], [5,5], [3,3], [1,3], [5,3], [3,1], [3,5]].forEach(([c, r]) => {
        positions.push({ col: c, row: r, layer: 1, priority: -3 });
      });
      [[1,1], [5,1], [1,5], [5,5], [3,3]].forEach(([c, r]) => {
        positions.push({ col: c, row: r, layer: 2, priority: -5 });
      });
      positions.push({ col: 3, row: 3, layer: 3, priority: -8 });
    } else if (pattern === "diamond") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          const d = Math.abs(c-3) + Math.abs(r-3);
          if (d <= 4) positions.push({ col: c, row: r, layer: 0, priority: d });
          if (d <= 3) positions.push({ col: c, row: r, layer: 1, priority: d - 2.5 });
          if (d <= 2) positions.push({ col: c, row: r, layer: 2, priority: d - 4.5 });
          if (d <= 1) positions.push({ col: c, row: r, layer: 3, priority: d - 6.5 });
        }
      }
    } else if (pattern === "star") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          const isCross = Math.abs(c-3) <= 1 || Math.abs(r-3) <= 1;
          const isCorner = (c <= 1 || c >= 5) && (r <= 1 || r >= 5);
          if (isCross || isCorner) {
            positions.push({ col: c, row: r, layer: 0, priority: Math.hypot(c-3, r-3) });
          }
        }
      }
      for (let r = 2; r <= 4; r++) {
        for (let c = 2; c <= 4; c++) {
          positions.push({ col: c, row: r, layer: 1, priority: Math.hypot(c-3, r-3) - 2 });
          positions.push({ col: c, row: r, layer: 2, priority: Math.hypot(c-3, r-3) - 4 });
        }
      }
      positions.push({ col: 3, row: 3, layer: 3, priority: -8 });
    } else if (pattern === "flower") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          const d = Math.hypot(c-3, r-3);
          if (d <= 3.4) positions.push({ col: c, row: r, layer: 0, priority: d });
        }
      }
      for (let r = 1; r <= 5; r++) {
        for (let c = 1; c <= 5; c++) {
          const d = Math.hypot(c-3, r-3);
          if (d <= 2.2) positions.push({ col: c, row: r, layer: 1, priority: d - 2 });
        }
      }
      [[2,2], [4,2], [2,4], [4,4], [3,3]].forEach(([c, r]) => {
        positions.push({ col: c, row: r, layer: 2, priority: -5 });
      });
      positions.push({ col: 3, row: 3, layer: 3, priority: -8 });
    } else if (pattern === "heart") {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          const inTop = r <= 2 && (c !== 3 || r >= 1);
          const inBottom = r > 2 && Math.abs(c-3) <= (6 - r) + 0.5;
          if (inTop || inBottom) {
            positions.push({ col: c, row: r, layer: 0, priority: Math.abs(c-3) + Math.abs(r-3) });
          }
        }
      }
      for (let r = 1; r <= 4; r++) {
        for (let c = 1; c <= 5; c++) {
          if (Math.abs(c-3) <= 2) {
            positions.push({ col: c, row: r, layer: 1, priority: -2 });
          }
        }
      }
      [[2,2], [4,2], [3,2], [3,3], [3,4]].forEach(([c, r]) => {
        positions.push({ col: c, row: r, layer: 2, priority: -5 });
      });
      positions.push({ col: 3, row: 2.5, layer: 3, priority: -8 });
    } else {
      // Labyrinth
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          const d = Math.max(Math.abs(c-3), Math.abs(r-3));
          positions.push({ col: c, row: r, layer: 0, priority: d });
          if (d <= 2) positions.push({ col: c, row: r, layer: 1, priority: d - 2 });
          if (d <= 1) positions.push({ col: c, row: r, layer: 2, priority: d - 4 });
        }
      }
      positions.push({ col: 3, row: 3, layer: 3, priority: -8 });
    }

    // Ensure plenty of candidates
    if (positions.length < targetCount + 12) {
      for (let r = 0; r <= 6; r++) {
        for (let c = 0; c <= 6; c++) {
          if (!positions.some(p => p.col === c && p.row === r && p.layer === 0)) {
            positions.push({ col: c, row: r, layer: 0, priority: 10 + Math.hypot(c - 3, r - 3) });
          }
        }
      }
    }

    positions.sort((a, b) => a.priority - b.priority);
    // Tile count must be a multiple of 3, otherwise the board can never be cleared
    const usable = Math.min(targetCount, positions.length);
    return positions.slice(0, Math.floor(usable / 3) * 3);
  }

  function makeBoardForLevel(level) {
    const { tileCount, fruitVariety, layoutType } = getLevelConfig(level);
    const theme = THEMES[state.currentTheme] || THEMES.fruits;
    const fruitPool = theme.tiles.slice(0, fruitVariety);

    const names = copy.layoutNames || {};
    state.layoutName = names[layoutType] || layoutType;

    const targetCount = Math.floor(tileCount / 3) * 3;
    const selectedPositions = getLayoutPositions(layoutType, targetCount);

    // Assign tiles in solvability-guaranteed reverse manner
    let boardTiles = null;
    for (let attempt = 0; attempt < 25; attempt++) {
      const tiles = selectedPositions.map((pos, idx) => ({
        ...pos,
        id: idx,
        fruit: null,
        removed: false,
        isGolden: false
      }));
      state.tiles = tiles;
      let assigned = 0;

      while (assigned < tiles.length) {
        const freeTiles = tiles.filter(t => !t.removed && !isBlocked(t));
        if (freeTiles.length < 3) break;

        let group;
        if (Math.random() < 0.35) {
          group = [];
          for (let i = 0; i < 3; i++) {
            group.push(freeTiles.splice(Math.floor(Math.random() * freeTiles.length), 1)[0]);
          }
        } else {
          group = freeTiles
            .map(t => ({ tile: t, tieBreak: Math.random() }))
            .sort((a, b) => b.tile.layer - a.tile.layer || a.tieBreak - b.tieBreak)
            .slice(0, 3)
            .map(e => e.tile);
        }
        const fruit = fruitPool[Math.floor(Math.random() * fruitPool.length)];
        group.forEach(t => {
          t.fruit = fruit;
          t.removed = true;
        });
        assigned += group.length;
      }

      if (assigned === tiles.length) {
        tiles.forEach(t => (t.removed = false));
        boardTiles = tiles;
        break;
      }
    }

    // Fallback if reverse generation missed
    if (!boardTiles) {
      const symbols = [];
      for (let i = 0; i < selectedPositions.length / 3; i++) {
        const fruit = fruitPool[Math.floor(Math.random() * fruitPool.length)];
        symbols.push(fruit, fruit, fruit);
      }
      for (let i = symbols.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [symbols[i], symbols[j]] = [symbols[j], symbols[i]];
      }
      boardTiles = selectedPositions.map((pos, idx) => ({
        ...pos,
        id: idx,
        fruit: symbols[idx],
        removed: false,
        isGolden: false
      }));
    }

    // Designate 1-2 Golden Bonus Tiles
    const candidates = boardTiles.filter(t => t.layer >= 1);
    const goldCount = targetCount >= 45 ? 2 : 1;
    for (let i = 0; i < goldCount && candidates.length > 0; i++) {
      const idx = Math.floor(Math.random() * candidates.length);
      candidates.splice(idx, 1)[0].isGolden = true;
    }

    state.tiles = boardTiles;
    state.tray = [];
    state.undoStack = [];
    state.hintHighlights.clear();
    state.ended = false;
    state.won = false;
    state.starsEarned = 0;
    state.comboMultiplier = 1;
    state.lastMatchAt = null;
    state.animations = [];
    state.screenShake = 0;
    state.focusId = firstAvailableTile()?.id ?? null;
  }

  function isBlocked(tile) {
    return state.tiles.some(other =>
      !other.removed &&
      other.layer > tile.layer &&
      Math.abs(other.col + other.layer * 0.14 - tile.col - tile.layer * 0.14) < 0.72 &&
      Math.abs(other.row + other.layer * 0.12 - tile.row - tile.layer * 0.12) < 0.72
    );
  }

  function firstAvailableTile() {
    return state.tiles.find(tile => !tile.removed && !isBlocked(tile));
  }

  // =========================================================================
  // POWERUPS LOGIC (Undo, Shuffle, Hint, Magic)
  // =========================================================================
  function useUndo() {
    if (state.ended || isPaused()) return;
    if (state.tray.length === 0 || state.undoStack.length === 0) {
      playSound("error");
      showMessage(copy.noMoves);
      return;
    }
    if (state.powerups.undo <= 0) {
      if (state.coins >= 50) {
        state.coins -= 50;
        state.powerups.undo += 1;
        playSound("coin");
      } else {
        playSound("error");
        showMessage(copy.needCoins);
        return;
      }
    }

    state.powerups.undo -= 1;
    const lastAction = state.undoStack.pop();
    const tile = lastAction.tile;

    // Remove from tray
    const trayIndex = state.tray.indexOf(tile);
    if (trayIndex >= 0) {
      state.tray.splice(trayIndex, 1);
    }
    tile.removed = false;

    // Reverse flight animation
    const trayPos = traySlotBounds(trayIndex >= 0 ? trayIndex : 0);
    const destPos = tilePosition(tile);
    state.animations.push({
      type: "flight_reverse",
      tile,
      fromX: trayPos.x + trayPos.width / 2,
      fromY: trayPos.y + trayPos.height / 2,
      toX: destPos.x + state.layout.tileW / 2,
      toY: destPos.y + state.layout.tileH / 2,
      elapsed: 0,
      duration: 220
    });

    playSound("powerup");
    saveState();
    draw();
  }

  function useShuffle() {
    if (state.ended || isPaused()) return;
    const activeTiles = state.tiles.filter(t => !t.removed);
    if (activeTiles.length === 0) return;

    if (state.powerups.shuffle <= 0) {
      state.boosterModal = { type: "shuffle", price: 60 };
      draw();
      return;
    }

    state.powerups.shuffle -= 1;
    const fruits = activeTiles.map(t => t.fruit);
    for (let i = fruits.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [fruits[i], fruits[j]] = [fruits[j], fruits[i]];
    }
    activeTiles.forEach((tile, index) => {
      tile.fruit = fruits[index];
    });

    // Shuffle sparkle animations
    state.animations.push({
      type: "shuffle_fx",
      elapsed: 0,
      duration: 350
    });

    playSound("powerup");
    showMessage(copy.shuffled);
    saveState();
    draw();
  }

  function useHint() {
    if (state.ended || isPaused()) return;
    const available = state.tiles.filter(t => !t.removed && !isBlocked(t));
    if (available.length === 0) return;

    if (state.powerups.hint <= 0) {
      state.boosterModal = { type: "hint", price: 60 };
      draw();
      return;
    }

    state.powerups.hint -= 1;
    state.hintHighlights.clear();

    // Check if 1 or 2 matching in tray
    const trayFruits = {};
    state.tray.forEach(t => {
      trayFruits[t.fruit] = (trayFruits[t.fruit] || 0) + 1;
    });

    let targetFruit = null;
    // Prefer fruit that is already in tray with count 2, then 1
    for (const [fruit, count] of Object.entries(trayFruits)) {
      if (count === 2) {
        if (available.some(t => t.fruit === fruit)) {
          targetFruit = fruit;
          break;
        }
      }
    }
    if (!targetFruit) {
      for (const [fruit, count] of Object.entries(trayFruits)) {
        if (count === 1) {
          const availCount = available.filter(t => t.fruit === fruit).length;
          if (availCount >= 2) {
            targetFruit = fruit;
            break;
          }
        }
      }
    }

    // Otherwise find 3 available on the board
    if (!targetFruit) {
      const counts = {};
      available.forEach(t => {
        counts[t.fruit] = (counts[t.fruit] || 0) + 1;
      });
      for (const [fruit, count] of Object.entries(counts)) {
        if (count >= 3) {
          targetFruit = fruit;
          break;
        }
      }
    }

    if (targetFruit) {
      available
        .filter(t => t.fruit === targetFruit)
        .slice(0, 3)
        .forEach(t => state.hintHighlights.add(t.id));
    } else {
      // Highlight any first available
      available.slice(0, 3).forEach(t => state.hintHighlights.add(t.id));
    }

    if (state.hintTimeout) clearTimeout(state.hintTimeout);
    state.hintTimeout = setTimeout(() => {
      state.hintHighlights.clear();
      draw();
    }, 4500);

    playSound("powerup");
    showMessage(copy.hintFound);
    saveState();
    draw();
  }

  function useMagic() {
    if (state.ended || isPaused()) return;
    if (state.powerups.magic <= 0) {
      if (state.coins >= 100) {
        state.coins -= 100;
        state.powerups.magic += 1;
        playSound("coin");
      } else {
        playSound("error");
        showMessage(copy.needCoins);
        return;
      }
    }

    state.powerups.magic -= 1;
    // If tray has tiles, remove up to 3 tiles to free up tray
    if (state.tray.length > 0) {
      const removed = state.tray.splice(0, Math.min(3, state.tray.length));
      playSound("match");
      showMessage(copy.magicUsed);
    } else {
      // Clear 3 available matching tiles from board
      const available = state.tiles.filter(t => !t.removed && !isBlocked(t));
      const counts = {};
      available.forEach(t => counts[t.fruit] = (counts[t.fruit] || 0) + 1);
      let matchFruit = Object.keys(counts).find(f => counts[f] >= 3) || (available[0] ? available[0].fruit : null);
      if (matchFruit) {
        const targets = available.filter(t => t.fruit === matchFruit).slice(0, 3);
        targets.forEach(t => (t.removed = true));
        state.score += 50;
        playSound("match");
        showMessage(`+50 Magic Match!`);
      }
    }

    // Check if won
    if (state.tiles.every(t => t.removed) && state.tray.length === 0) {
      finishBoard(true);
    }

    saveState();
    draw();
  }

  function reviveGame() {
    if (state.coins >= 60) {
      state.coins -= 60;
      // Clear 3 tiles from tray
      state.tray.splice(0, Math.min(3, state.tray.length));
      state.ended = false;
      state.won = false;
      playSound("powerup");
      showMessage("Revived!");
      saveState();
      draw();
    } else {
      playSound("error");
      showMessage(copy.needCoins);
    }
  }

  // =========================================================================
  // SELECTION & MATCH LOGIC
  // =========================================================================
  function selectTile(tile) {
    if (state.ended || isPaused() || isBlocked(tile)) return;
    tile.removed = true;
    state.undoStack.push({ tile });

    // Smart adjacent tray insertion
    let insertIndex = -1;
    for (let i = state.tray.length - 1; i >= 0; i--) {
      if (state.tray[i].fruit === tile.fruit) {
        insertIndex = i + 1;
        break;
      }
    }
    if (insertIndex !== -1) {
      state.tray.splice(insertIndex, 0, tile);
    } else {
      state.tray.push(tile);
    }

    state.hintHighlights.delete(tile.id);

    if (navigator.vibrate) {
      navigator.vibrate(15);
    }

    state.animations.push({
      type: "flight",
      tile,
      elapsed: 0,
      duration: 180
    });

    // Check if Golden Bonus Tile
    if (tile.isGolden && !tile.goldPaid) {
      tile.goldPaid = true; // pay once, even if the tile is undone and picked again
      state.coins += 20;
      playSound("gold");
      const tilePos = tilePosition(tile);
      state.animations.push({
        type: "goldenBonus",
        x: state.width / 2,
        y: state.layout ? state.layout.trayY - 26 : state.height / 2,
        elapsed: 0,
        duration: 900
      });
      const goldParticles = Array.from({ length: 14 }, () => ({
        x: tilePos.x + (state.layout ? state.layout.tileW / 2 : 20),
        y: tilePos.y + (state.layout ? state.layout.tileH / 2 : 20),
        vx: (Math.random() - 0.5) * 5,
        vy: -1.5 - Math.random() * 3,
        radius: 0.05 + Math.random() * 0.04,
        color: "#ffd700"
      }));
      state.animations.push({ type: "particlesRaw", particles: goldParticles, elapsed: 0, duration: 600 });
    }

    const matching = state.tray.filter(item => item.fruit === tile.fruit);
    let sound = "tap";

    if (matching.length === 3) {
      state.tutorialDone = true;
      sound = "match";
      state.screenShake = 4.0;
      if (navigator.vibrate) {
        navigator.vibrate([25, 30, 25]);
      }

      const matchedIds = new Set(matching.map(i => i.id));
      const matchItems = matching.map(matchedTile => ({
        tile: matchedTile,
        slotIndex: state.tray.indexOf(matchedTile)
      }));

      state.animations = state.animations.filter(
        a => a.type !== "flight" || !matchedIds.has(a.tile.id)
      );

      state.animations.push({
        type: "pop",
        items: matchItems,
        elapsed: 0,
        duration: 220
      });

      // Celebration particles
      const particles = Array.from({ length: 18 }, (_, idx) => ({
        item: matchItems[idx % matchItems.length],
        vx: (Math.random() - 0.5) * 6.5,
        vy: -1.5 - Math.random() * 2.8,
        radius: 0.04 + Math.random() * 0.04,
        color: ACCENT_COLORS[Math.floor(Math.random() * ACCENT_COLORS.length)]
      }));
      state.animations.push({ type: "particles", particles, elapsed: 0, duration: 520 });

      state.tray = state.tray.filter(i => !matchedIds.has(i.id));

      const matchTime = performance.now();
      state.comboMultiplier = state.lastMatchAt !== null && matchTime - state.lastMatchAt <= 4200
        ? Math.min(5, state.comboMultiplier + 1)
        : 1;
      state.lastMatchAt = matchTime;

      const points = 30 * state.comboMultiplier;
      state.score += points;
      state.bestScore = Math.max(state.bestScore, state.score);

      // Reward coins & juicy combo presentation
      if (state.comboMultiplier >= 2) {
        state.coins += state.comboMultiplier * 2;
        playSound("combo");
        state.screenShake = 6.0;

        let comboTitle = copy.comboGood || "YAXSHI!";
        if (state.comboMultiplier === 3) comboTitle = copy.comboGreat || "AJOYIB!";
        else if (state.comboMultiplier === 4) comboTitle = copy.comboAwesome || "DAHSHAT!";
        else if (state.comboMultiplier >= 5) comboTitle = copy.comboSuper || "SUPER FEVER! 🔥";

        state.animations.push({
          type: "comboText",
          title: comboTitle,
          multiplier: state.comboMultiplier,
          points: points,
          elapsed: 0,
          duration: 900
        });
      } else {
        state.animations.push({
          type: "scoreFloat",
          points: points,
          elapsed: 0,
          duration: 700
        });
      }

      saveState();
    }

    if (state.tray.length >= 7) {
      finishBoard(false);
    } else if (state.tiles.every(i => i.removed) && state.tray.length === 0) {
      finishBoard(true);
    }

    if (!state.ended) playSound(sound);
    state.focusId = firstAvailableTile()?.id ?? null;
    draw();
  }

  function finishBoard(won) {
    if (state.ended) return;
    state.ended = true;
    state.won = won;
    state.bestScore = Math.max(state.bestScore, state.score);

    if (won) {
      // Track levels cleared for interstitial pacing (ad every 3 levels)
      state.levelsCompletedSinceAd = (state.levelsCompletedSinceAd || 0) + 1;

      // Calculate stars based on remaining tray space
      const emptySlots = 7 - state.tray.length;
      if (emptySlots >= 5) state.starsEarned = 3;
      else if (emptySlots >= 3) state.starsEarned = 2;
      else state.starsEarned = 1;

      // Coins reward
      const coinsWon = 30 + state.starsEarned * 15;
      state.coins += coinsWon;

      // Update level progress
      const prev = state.levelsProgress[state.level] || { stars: 0, score: 0 };
      state.levelsProgress[state.level] = {
        stars: Math.max(prev.stars, state.starsEarned),
        score: Math.max(prev.score, state.score)
      };
      // Unlock next level
      if (!state.levelsProgress[state.level + 1]) {
        state.levelsProgress[state.level + 1] = { stars: 0, score: 0 };
      }

      playSound("win");
      state.screenShake = 5.0;

      // Win-screen sequence (card pop, stars one by one, coin count-up, confetti)
      state.winAt = performance.now();
      state.winCoins = coinsWon;
      state.winStarsPlayed = 0;
      state.winConfetti = makeWinConfetti();

      notifyPlatform("level_completed");
    } else {
      playSound("lose");
      notifyPlatform("level_failed");
    }

    saveState();
  }

  // =========================================================================
  // PLATFORM & BRIDGE HELPERS
  // =========================================================================
  function notifyPlatform(msg) {
    const bridge = window.fruitTileDependencies?.bridge;
    if (!bridge) return;
    bridge.platform.sendMessage(msg).catch(() => {});
  }

  function showInterstitialAd(placement, onComplete) {
    const bridge = window.fruitTileDependencies?.bridge;
    if (state.adInProgress) return;

    if (!bridge || !bridge.advertisement?.isInterstitialSupported) {
      if (typeof onComplete === "function") onComplete();
      return;
    }

    state.adInProgress = true;
    let handled = false;
    let safetyTimer = null;

    function cleanup() {
      state.adInProgress = false;
      if (safetyTimer) {
        clearTimeout(safetyTimer);
        safetyTimer = null;
      }
      try {
        bridge.advertisement.off(bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED, stateHandler);
      } catch (e) {}
    }

    function stateHandler(adState) {
      if (handled) return;
      if (adState === bridge.INTERSTITIAL_STATE.CLOSED || adState === bridge.INTERSTITIAL_STATE.FAILED) {
        handled = true;
        cleanup();
        if (typeof onComplete === "function") onComplete();
      }
    }

    try {
      bridge.advertisement.on(bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED, stateHandler);
      bridge.advertisement.showInterstitial(placement);
    } catch (err) {
      console.warn("[Fruit Tile Match] Interstitial ad error:", err);
      if (!handled) {
        handled = true;
        cleanup();
        if (typeof onComplete === "function") onComplete();
      }
      return;
    }

    safetyTimer = setTimeout(() => {
      if (!handled) {
        handled = true;
        cleanup();
        if (typeof onComplete === "function") onComplete();
      }
    }, 8000);
  }

  function showRewardedAd(placement, onSuccess) {
    const bridge = window.fruitTileDependencies?.bridge;
    if (state.adInProgress) return;

    if (!bridge || !bridge.advertisement?.isRewardedSupported) {
      playSound("error");
      showMessage(copy.adUnavailable);
      return;
    }

    state.adInProgress = true;
    draw();

    let rewardEarned = false;
    let handled = false;
    let safetyTimer = null;

    function cleanup() {
      state.adInProgress = false;
      if (safetyTimer) {
        clearTimeout(safetyTimer);
        safetyTimer = null;
      }
      try {
        bridge.advertisement.off(bridge.EVENT_NAME.REWARDED_STATE_CHANGED, stateHandler);
      } catch (e) {}
      draw();
    }

    function stateHandler(adState) {
      if (handled) return;

      if (adState === bridge.REWARDED_STATE.REWARDED) {
        rewardEarned = true;
      } else if (adState === bridge.REWARDED_STATE.CLOSED) {
        handled = true;
        cleanup();
        if (rewardEarned) {
          if (typeof onSuccess === "function") onSuccess();
        } else {
          showMessage(copy.adClosedEarly);
        }
      } else if (adState === bridge.REWARDED_STATE.FAILED) {
        handled = true;
        cleanup();
        showMessage(copy.adUnavailable);
      }
    }

    try {
      bridge.advertisement.on(bridge.EVENT_NAME.REWARDED_STATE_CHANGED, stateHandler);
      bridge.advertisement.showRewarded(placement);
    } catch (err) {
      console.warn("[Fruit Tile Match] Rewarded ad error:", err);
      if (!handled) {
        handled = true;
        cleanup();
        showMessage(copy.adUnavailable);
      }
      return;
    }

    safetyTimer = setTimeout(() => {
      if (!handled) {
        handled = true;
        cleanup();
        showMessage(copy.adUnavailable);
      }
    }, 15000);
  }

  function showMessage(msg) {
    state.message = msg;
    state.messageUntil = performance.now() + 2400;
    if (messageTimeout) clearTimeout(messageTimeout);
    messageTimeout = setTimeout(draw, 2450);
  }

  // =========================================================================
  // LAYOUT & RENDERING
  // =========================================================================
  function resize() {
    const bounds = canvas.getBoundingClientRect();
    state.width = bounds.width;
    state.height = bounds.height;
    state.pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(state.width * state.pixelRatio);
    canvas.height = Math.round(state.height * state.pixelRatio);
    ctx.setTransform(state.pixelRatio, 0, 0, state.pixelRatio, 0, 0);
    calculateLayout();
    draw();
  }

  function calculateLayout() {
    const w = state.width;
    const h = state.height;
    const isMobile = w < 600;
    const landscapePhone = w > h && h < 520;
    const headerH = landscapePhone ? 50 : 70;
    const powerupsH = landscapePhone ? 58 : 72;
    const trayH = landscapePhone ? 75 : Math.max(90, Math.min(115, h * 0.16));
    const top = headerH + 8;
    const boardBottom = h - trayH - powerupsH - 12;

    const size = Math.max(12, Math.min(
      62,
      (w - 28) / 8.2,
      (boardBottom - top - 8) / 7.6
    ));

    const tileW = size * 0.94;
    const tileH = size * 1.08;
    const stepX = size * 0.99;
    const stepY = size * 0.96;
    const boardW = stepX * 7 + tileW + size * 0.14 * 2;
    const boardH = stepY * 7 + tileH + size * 0.12 * 2;
    const boardX = (w - boardW) / 2;
    const boardY = top + Math.max(0, (boardBottom - top - boardH) / 2);

    const slotW = Math.min(46, (w - 36) / 7.2);
    const slotGap = Math.min(6, slotW * 0.12);
    const totalTrayW = slotW * 7 + slotGap * 6;
    const trayX = (w - totalTrayW) / 2;
    const trayY = h - trayH - powerupsH;
    const powerupsY = h - powerupsH;

    state.layout = {
      isMobile,
      landscapePhone,
      headerH,
      trayH,
      powerupsH,
      powerupsY,
      size,
      tileW,
      tileH,
      stepX,
      stepY,
      boardX,
      boardY,
      slotW,
      slotGap,
      trayX,
      trayY,
      totalTrayW,
      btnMap: {}
    };
  }

  function roundedRect(x, y, w, h, radius) {
    const r = Math.max(0, Math.min(radius, w / 2, h / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function text(val, x, y, size, color, weight, align) {
    ctx.font = `${weight || 700} ${size}px "Quicksand", "Segoe UI", sans-serif`;
    ctx.fillStyle = color;
    ctx.textAlign = align || "left";
    ctx.textBaseline = "middle";
    ctx.fillText(val, x, y);
  }

  // ---- Screen transitions ----
  const TRANS_MS = 340;
  let transSnap = null;
  let transStart = 0;
  let transDir = 1;
  let transActive = false;

  function easeOutBack(t) {
    const n = Math.max(0, Math.min(1, t));
    const c1 = 1.70158;
    const c3 = c1 + 1;
    return 1 + c3 * Math.pow(n - 1, 3) + c1 * Math.pow(n - 1, 2);
  }

  // Captures the frame currently on screen; draw() then fades/slides it away.
  function beginTransition(dir) {
    if (!state.layout || !canvas.width) return;
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    try {
      if (!transSnap) transSnap = document.createElement("canvas");
      transSnap.width = canvas.width;
      transSnap.height = canvas.height;
      transSnap.getContext("2d").drawImage(canvas, 0, 0);
      transStart = performance.now();
      transDir = dir;
      transActive = true;
    } catch (err) {
      transActive = false;
    }
  }

  function drawTransition(now) {
    if (!transActive || !transSnap) return;
    const p = easeOut((now - transStart) / TRANS_MS);
    if (p >= 1) {
      transActive = false;
      return;
    }
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1 - p;
    ctx.drawImage(transSnap, -transDir * p * canvas.width * 0.18, 0);
    ctx.restore();
  }

  // ---- Daily play streak ----
  function dateKey(offsetDays) {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${d.getFullYear()}-${mm}-${dd}`;
  }

  // Returns true when the streak grew today.
  function touchStreak() {
    const s = state.streak;
    const today = dateKey(0);
    if (s.lastDate === today) return false;
    s.count = s.lastDate === dateKey(-1) ? s.count + 1 : 1;
    s.best = Math.max(s.best, s.count);
    s.lastDate = today;
    return true;
  }

  // status: "active" (played today), "atrisk" (played yesterday), "none" (broken / new)
  function getStreakInfo() {
    const s = state.streak;
    if (s.lastDate === dateKey(0)) return { count: s.count, status: "active" };
    if (s.lastDate === dateKey(-1)) return { count: s.count, status: "atrisk" };
    return { count: 0, status: "none" };
  }

  // ---- Win screen confetti ----
  function makeWinConfetti() {
    const w = state.width || 400;
    const h = state.height || 700;
    const colors = ACCENT_COLORS.concat(["#ffd43b", "#ff6b6b", "#69db7c"]);
    const items = [];
    // Falling rain
    for (let i = 0; i < 70; i++) {
      items.push({
        kind: "rain",
        x: Math.random() * w,
        vx: (Math.random() - 0.5) * 30,
        vy: 110 + Math.random() * 150,
        delay: Math.random() * 1.4,
        w: 6 + Math.random() * 6,
        h: 10 + Math.random() * 8,
        rot: Math.random() * 6.28,
        vRot: (Math.random() - 0.5) * 8,
        sway: 8 + Math.random() * 14,
        freq: 1.5 + Math.random() * 2,
        ph: Math.random() * 6.28,
        color: colors[Math.floor(Math.random() * colors.length)],
        emoji: Math.random() < 0.14 ? ["⭐", "✨", "🎉"][Math.floor(Math.random() * 3)] : null
      });
    }
    // Two cannons from the bottom corners
    for (let c = 0; c < 2; c++) {
      for (let i = 0; i < 26; i++) {
        const dir = c === 0 ? 1 : -1;
        items.push({
          kind: "burst",
          x: c === 0 ? 10 : w - 10,
          y: h - 10,
          vx: dir * (80 + Math.random() * 260),
          vy: -(380 + Math.random() * 380),
          w: 6 + Math.random() * 5,
          h: 9 + Math.random() * 7,
          rot: Math.random() * 6.28,
          vRot: (Math.random() - 0.5) * 12,
          color: colors[Math.floor(Math.random() * colors.length)]
        });
      }
    }
    return items;
  }

  function drawWinConfetti(el) {
    const items = state.winConfetti;
    if (!items) return;
    const w = state.width;
    const h = state.height;
    const t0 = el / 1000;
    ctx.save();
    for (const p of items) {
      let x;
      let y;
      let t;
      if (p.kind === "burst") {
        t = t0;
        if (t > 2.6) continue;
        x = p.x + p.vx * t;
        y = p.y + p.vy * t + 0.5 * 700 * t * t;
        ctx.globalAlpha = clamp01((2.6 - t) / 0.6);
      } else {
        t = t0 - p.delay;
        if (t < 0) continue;
        const period = (h + 60) / p.vy;
        t = t % period;
        x = p.x + p.vx * t + Math.sin(t * p.freq + p.ph) * p.sway;
        y = -20 + p.vy * t;
        ctx.globalAlpha = 1;
      }
      if (y > h + 30 || y < -60) continue;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(p.rot + p.vRot * t);
      if (p.emoji) {
        ctx.font = `18px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(p.emoji, 0, 0);
      } else {
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      }
      ctx.restore();
    }
    ctx.restore();
  }

  // ---- First-time tutorial (level 1): pointing hand + hint banner ----
  function getTutorialTarget() {
    const free = state.tiles.filter(t => !t.removed && !isBlocked(t));
    if (!free.length) return null;
    if (state.tray.length > 0) {
      const counts = {};
      state.tray.forEach(t => { counts[t.fruit] = (counts[t.fruit] || 0) + 1; });
      const best = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
      const match = free.find(t => t.fruit === best);
      if (match) return { tile: match, more: true };
    }
    const fc = {};
    free.forEach(t => { fc[t.fruit] = (fc[t.fruit] || 0) + 1; });
    const best = Object.keys(fc).sort((a, b) => fc[b] - fc[a])[0];
    return { tile: free.find(t => t.fruit === best), more: false };
  }

  function drawTutorial() {
    if (state.level !== 1 || state.tutorialDone || state.ended || state.boosterModal || isPaused()) return;
    const target = getTutorialTarget();
    if (!target || !target.tile) return;
    const L = state.layout;
    const t = performance.now() / 1000;
    const pos = tilePosition(target.tile);
    const cx = pos.x + L.tileW / 2;
    const cy = pos.y + L.tileH / 2;

    // pulsing highlight
    ctx.save();
    ctx.strokeStyle = "#ffd43b";
    ctx.lineWidth = 5;
    ctx.globalAlpha = 0.7 + 0.3 * Math.sin(t * 4);
    roundedRect(pos.x - 4, pos.y - 4, L.tileW + 8, L.tileH + 8, 14);
    ctx.stroke();
    ctx.restore();

    // bobbing hand
    const bob = Math.abs(Math.sin(t * 3.2)) * 10;
    text("👆", cx + L.tileW * 0.15, cy + L.tileH * 0.98 + bob, Math.max(26, L.size * 0.8), "#000", 400, "center");

    // banner above the topmost tile (or below the board when there is no room)
    let minY = Infinity;
    let maxY = -Infinity;
    state.tiles.forEach(tile => {
      if (tile.removed) return;
      const p = tilePosition(tile);
      minY = Math.min(minY, p.y);
      maxY = Math.max(maxY, p.y + L.tileH);
    });
    let by = minY - 36;
    if (by < L.headerH) by = Math.min(maxY + 8, L.trayY - 36);
    const msg = target.more ? copy.tutorialMore : copy.tutorialTap;
    ctx.font = `800 13px "Quicksand", "Segoe UI", sans-serif`;
    const bw = Math.min(state.width - 24, ctx.measureText(msg).width + 36);
    ctx.save();
    ctx.shadowColor = "rgba(40, 80, 110, 0.2)";
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 3;
    roundedRect((state.width - bw) / 2, by, bw, 28, 14);
    ctx.fillStyle = "rgba(255, 255, 255, 0.96)";
    ctx.fill();
    ctx.restore();
    roundedRect((state.width - bw) / 2, by, bw, 28, 14);
    ctx.strokeStyle = "#ffd43b";
    ctx.lineWidth = 2;
    ctx.stroke();
    text(msg, state.width / 2, by + 15, 13, "#184e68", 800, "center");
  }

  // ---- Animated background & menu helpers ----
  let menuShownAt = 0;
  let prevScreen = null;

  function isDarkTheme() {
    return (THEMES[state.currentTheme] || THEMES.fruits).id === "space";
  }

  function hexToRgba(hex, alpha) {
    const n = parseInt(String(hex).slice(1), 16);
    return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
  }

  function clamp01(v) {
    return Math.max(0, Math.min(1, v));
  }

  function drawBackground(intensity) {
    const k = intensity === undefined ? 1 : intensity;
    const theme = THEMES[state.currentTheme] || THEMES.fruits;
    const dark = theme.id === "space";
    const w = state.width;
    const h = state.height;
    const t = performance.now() / 1000;

    // Base gradient
    const gradient = ctx.createLinearGradient(0, 0, w * 0.6, h);
    gradient.addColorStop(0, theme.bgGradient[0]);
    gradient.addColorStop(1, theme.bgGradient[1]);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);

    // Slowly drifting soft colour blobs (gives depth)
    const maxSide = Math.max(w, h);
    const blobs = [
      { cx: 0.15, cy: 0.22, r: 0.55, sp: 0.11, ph: 0 },
      { cx: 0.88, cy: 0.40, r: 0.50, sp: 0.09, ph: 2 },
      { cx: 0.50, cy: 0.92, r: 0.60, sp: 0.07, ph: 4 }
    ];
    blobs.forEach(b => {
      const x = (b.cx + Math.sin(t * b.sp * 2 + b.ph) * 0.08) * w;
      const y = (b.cy + Math.cos(t * b.sp * 2 + b.ph) * 0.06) * h;
      const r = b.r * maxSide * 0.6;
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, hexToRgba(theme.accentColor, 0.17 * k));
      g.addColorStop(1, hexToRgba(theme.accentColor, 0));
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);
    });

    // Floating theme icons drifting upward
    const icons = theme.tiles.slice(0, 8);
    const count = w < 500 ? 10 : 16;
    ctx.save();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (let i = 0; i < count; i++) {
      const size = 20 + ((i * 37) % 24);
      const speed = 10 + ((i * 13) % 16);
      const span = h + size * 2;
      const y = h + size - ((t * speed + ((i * 131) % span)) % span);
      const x = (((i * 173) % 1000) / 1000) * w + Math.sin(t * 0.6 + i) * 14;
      ctx.globalAlpha = (dark ? 0.17 : 0.13) * k;
      ctx.font = `${size}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.sin(t * 0.5 + i) * 0.35);
      ctx.fillText(icons[i % icons.length], 0, 0);
      ctx.restore();
    }
    ctx.restore();

    // Twinkling sparkle dots
    ctx.save();
    for (let i = 0; i < 14; i++) {
      const x = (i * 149 + 30) % w;
      const y = (i * 211 + 25) % h;
      ctx.globalAlpha = (0.08 + 0.16 * (0.5 + 0.5 * Math.sin(t * 1.3 + i * 1.7))) * k;
      ctx.fillStyle = dark ? "#e0f2fe" : ACCENT_COLORS[i % ACCENT_COLORS.length];
      ctx.beginPath();
      ctx.arc(x, y, 3 + (i % 3) * 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function outlinedTitle(val, x, y, size, fill, outline) {
    ctx.save();
    ctx.font = `800 ${size}px "Quicksand", "Segoe UI", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    ctx.lineWidth = Math.max(4, size * 0.16);
    ctx.shadowColor = "rgba(20, 60, 90, 0.25)";
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 4;
    ctx.strokeStyle = outline;
    ctx.strokeText(val, x, y);
    ctx.shadowColor = "transparent";
    ctx.fillStyle = fill;
    ctx.fillText(val, x, y);
    ctx.restore();
  }

  function drawMenuScreen() {
    drawBackground(1);
    const w = state.width;
    const h = state.height;
    const layout = state.layout;
    layout.btnMap = {};
    const now = performance.now();
    const t = now / 1000;
    const theme = THEMES[state.currentTheme] || THEMES.fruits;
    const dark = theme.id === "space";
    const ink = dark ? "#f1f5f9" : "#184e68";
    const sub = dark ? "#cbd5e1" : "#487a94";
    const outline = dark ? "#0f172a" : "#ffffff";
    const cardFill = dark ? "rgba(30, 41, 59, 0.94)" : "#ffffff";
    const chipFill = dark ? "rgba(30, 41, 59, 0.9)" : "rgba(255, 255, 255, 0.9)";

    // ---- Top bar chips ----
    const chip = (x, y, cw, ch, stroke) => {
      ctx.save();
      ctx.shadowColor = "rgba(40, 80, 110, 0.14)";
      ctx.shadowBlur = 8;
      ctx.shadowOffsetY = 2;
      roundedRect(x, y, cw, ch, ch / 2);
      ctx.fillStyle = chipFill;
      ctx.fill();
      ctx.restore();
      roundedRect(x, y, cw, ch, ch / 2);
      ctx.strokeStyle = stroke;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    };

    chip(w - 130, 16, 114, 38, "#ffe066");
    text("🪙", w - 112, 35, 18, "#000", 700, "center");
    text(`${state.coins}`, w - 66, 35, 16, "#e67700", 800, "center");

    chip(16, 16, 42, 38, "#d0ebff");
    text(state.soundEnabled ? "🔊" : "🔇", 37, 35, 18, "#000", 700, "center");
    layout.btnMap.soundToggle = { x: 16, y: 16, w: 42, h: 38 };

    chip(66, 16, 42, 38, "#d0ebff");
    text(state.musicEnabled ? "🎵" : "🔈", 87, 35, 18, "#000", 700, "center");
    layout.btnMap.musicToggle = { x: 66, y: 16, w: 42, h: 38 };

    const langLabel = state.language === "uz" ? "🇺🇿 UZ" : state.language === "ru" ? "🇷🇺 RU" : "🇬🇧 EN";
    chip(116, 16, 68, 38, "#d0ebff");
    text(langLabel, 150, 35, 13, ink, 800, "center");
    layout.btnMap.langToggle = { x: 116, y: 16, w: 68, h: 38 };

    // ---- Layout (adapts to phones, landscape and desktop) ----
    const wide = w > h * 1.3 && h < 560;
    const compact = h < 600;
    const btnW = Math.min(300, wide ? w * 0.42 : w - 48);
    const heroH = compact ? 50 : 62;
    const btnH = compact ? 42 : 54;
    const gap = compact ? 9 : 13;
    const buttonsH = heroH + 3 * btnH + 3 * gap;
    const reserve = 80; // room for the streak row at the bottom
    const iconSize = compact ? 52 : 72;
    const titleSize = Math.min(compact ? 30 : 42, w * 0.09);
    const logoBlock = iconSize + titleSize + 66;

    let cxLogo = w / 2;
    let cxBtn = w / 2;
    let logoTop;
    let btnTop;
    if (wide) {
      cxLogo = w * 0.27;
      cxBtn = w * 0.72;
      logoTop = 60 + Math.max(0, (h - reserve - 60 - logoBlock) / 2);
      btnTop = 60 + Math.max(0, (h - reserve - 60 - buttonsH) / 2);
    } else {
      const contentH = logoBlock + 20 + buttonsH;
      logoTop = 64 + Math.max(0, (h - reserve - 64 - contentH) / 2);
      btnTop = logoTop + logoBlock + 20;
    }

    // ---- Logo with glow, bobbing icon ----
    const logoY = logoTop + iconSize * 0.55;
    const glowR = iconSize * (1.0 + 0.06 * Math.sin(t * 2));
    const glow = ctx.createRadialGradient(cxLogo, logoY, 0, cxLogo, logoY, glowR);
    glow.addColorStop(0, hexToRgba(theme.accentColor, 0.30));
    glow.addColorStop(1, hexToRgba(theme.accentColor, 0));
    ctx.fillStyle = glow;
    ctx.fillRect(cxLogo - glowR, logoY - glowR, glowR * 2, glowR * 2);

    ctx.save();
    ctx.translate(cxLogo, logoY + Math.sin(t * 2.2) * 6);
    const sc = 1 + 0.04 * Math.sin(t * 4.4);
    ctx.scale(sc, sc);
    ctx.rotate(Math.sin(t * 1.6) * 0.07);
    text(theme.icon || "🍓", 0, 0, iconSize, "#000", 400, "center");
    ctx.restore();

    // Title (shrinks to fit narrow screens)
    let tSize = titleSize;
    ctx.font = `800 ${tSize}px "Quicksand", "Segoe UI", sans-serif`;
    const maxTitleW = wide ? w * 0.46 : w - 32;
    const measured = ctx.measureText(copy.title).width;
    if (measured > maxTitleW) tSize = Math.max(18, tSize * (maxTitleW / measured));
    const titleY = logoTop + iconSize + tSize * 0.75 + 8;
    outlinedTitle(copy.title, cxLogo, titleY, tSize, ink, outline);

    // Stats pill
    const statsY = titleY + tSize * 0.75 + 20;
    const statsText = `🏆 ${copy.level} ${state.level}   •   ⭐ ${copy.best}: ${state.bestScore}`;
    ctx.font = `700 13px "Quicksand", "Segoe UI", sans-serif`;
    const pillW = Math.min(maxTitleW + 20, ctx.measureText(statsText).width + 30);
    roundedRect(cxLogo - pillW / 2, statsY - 14, pillW, 28, 14);
    ctx.fillStyle = dark ? "rgba(30, 41, 59, 0.75)" : "rgba(255, 255, 255, 0.7)";
    ctx.fill();
    text(statsText, cxLogo, statsY, 13, sub, 700, "center");

    // ---- Buttons (staggered slide-in) ----
    const bx = cxBtn - btnW / 2;
    const since = now - menuShownAt;
    const enter = i => {
      const e = clamp01((since - i * 90) / 450);
      return 1 - Math.pow(1 - e, 3);
    };

    // 1. PLAY (pulsing + shine sweep)
    const playY = btnTop;
    const e0 = enter(0);
    ctx.save();
    ctx.globalAlpha = e0;
    ctx.translate(cxBtn, playY + heroH / 2 + (1 - e0) * 30);
    const pulse = 1 + 0.025 * Math.sin(t * 3.2);
    ctx.scale(pulse, pulse);
    const pGrad = ctx.createLinearGradient(0, -heroH / 2, 0, heroH / 2);
    pGrad.addColorStop(0, "#51d46a");
    pGrad.addColorStop(1, "#2b9a43");
    ctx.save();
    ctx.shadowColor = "rgba(47, 158, 68, 0.45)";
    ctx.shadowBlur = 16;
    ctx.shadowOffsetY = 6;
    roundedRect(-btnW / 2, -heroH / 2, btnW, heroH, 22);
    ctx.fillStyle = pGrad;
    ctx.fill();
    ctx.restore();
    // top gloss
    ctx.save();
    roundedRect(-btnW / 2, -heroH / 2, btnW, heroH, 22);
    ctx.clip();
    const gloss = ctx.createLinearGradient(0, -heroH / 2, 0, 0);
    gloss.addColorStop(0, "rgba(255,255,255,0.28)");
    gloss.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = gloss;
    ctx.fillRect(-btnW / 2, -heroH / 2, btnW, heroH / 2);
    // shine sweep every ~3s
    const phase = (t % 3) / 1.1;
    if (phase < 1) {
      const sx = -btnW / 2 - 60 + phase * (btnW + 120);
      const shine = ctx.createLinearGradient(sx, 0, sx + 50, 0);
      shine.addColorStop(0, "rgba(255,255,255,0)");
      shine.addColorStop(0.5, "rgba(255,255,255,0.35)");
      shine.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = shine;
      ctx.fillRect(-btnW / 2, -heroH / 2, btnW, heroH);
    }
    ctx.restore();
    ctx.shadowColor = "rgba(0,0,0,0.25)";
    ctx.shadowBlur = 4;
    ctx.shadowOffsetY = 2;
    text(`▶  ${copy.play}`, 0, 0, compact ? 20 : 24, "#ffffff", 800, "center");
    ctx.restore();
    layout.btnMap.play = { x: bx, y: playY, w: btnW, h: heroH };

    // 2-4. Secondary buttons with icon badges
    const secondary = [
      { key: "levels", icon: "🗺️", label: copy.levels, color: dark ? "#8ce99a" : "#2b8a3e", tint: "#ebfbee", stroke: "#c3e6cb" },
      { key: "themes", icon: "🎨", label: copy.themes, color: dark ? "#d0bfff" : "#6741d9", tint: "#f3f0ff", stroke: "#e5dbff" },
      { key: "rewards", icon: "🎁", label: copy.dailyReward, color: dark ? "#ffc078" : "#d9480f", tint: "#fff4e6", stroke: "#ffd8a8" }
    ];
    secondary.forEach((b, i) => {
      const y = playY + heroH + gap + i * (btnH + gap);
      const e = enter(i + 1);
      ctx.save();
      ctx.globalAlpha = e;
      ctx.translate(0, (1 - e) * 30);

      ctx.save();
      ctx.shadowColor = "rgba(40, 80, 110, 0.14)";
      ctx.shadowBlur = 10;
      ctx.shadowOffsetY = 4;
      roundedRect(bx, y, btnW, btnH, 20);
      ctx.fillStyle = cardFill;
      ctx.fill();
      ctx.restore();
      roundedRect(bx, y, btnW, btnH, 20);
      ctx.strokeStyle = b.stroke;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // icon badge
      const r = btnH * 0.33;
      ctx.beginPath();
      ctx.arc(bx + btnH * 0.55, y + btnH / 2, r, 0, Math.PI * 2);
      ctx.fillStyle = b.tint;
      ctx.fill();
      text(b.icon, bx + btnH * 0.55, y + btnH / 2 + 1, btnH * 0.38, "#000", 400, "center");

      text(b.label, cxBtn, y + btnH / 2, compact ? 15 : 17, b.color, 800, "center");
      text("›", bx + btnW - 20, y + btnH / 2 - 1, 22, b.color, 700, "center");

      // red dot when the daily reward is ready
      if (b.key === "rewards" && getDailyRewardStatus().canClaim) {
        const dotR = 7 + Math.sin(t * 5) * 1.2;
        ctx.beginPath();
        ctx.arc(bx + btnW - 42, y + 15, dotR, 0, Math.PI * 2);
        ctx.fillStyle = "#ff6b6b";
        ctx.fill();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      ctx.restore();
      layout.btnMap[b.key] = { x: bx, y, w: btnW, h: btnH };
    });

    // ---- Daily streak row (bottom) ----
    const info = getStreakInfo();
    const rowW = Math.min(w - 32, 300);
    const rowH = 34;
    const rx = (w - rowW) / 2;
    const ry = h - 70;
    const sEnter = enter(4);
    ctx.save();
    ctx.globalAlpha = sEnter;
    ctx.translate(0, (1 - sEnter) * 20);

    ctx.save();
    ctx.shadowColor = "rgba(230, 119, 0, 0.18)";
    ctx.shadowBlur = 10;
    ctx.shadowOffsetY = 3;
    roundedRect(rx, ry, rowW, rowH, rowH / 2);
    ctx.fillStyle = cardFill;
    ctx.fill();
    ctx.restore();
    roundedRect(rx, ry, rowW, rowH, rowH / 2);
    ctx.strokeStyle = info.status === "active" ? "#ffa94d" : "#ffd8a8";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // flame (pulses while the streak is alive)
    ctx.save();
    ctx.translate(rx + 22, ry + rowH / 2 + 1);
    const fl = info.status === "active" ? 1 + 0.1 * Math.sin(t * 6) : 1;
    ctx.scale(fl, fl);
    ctx.globalAlpha = sEnter * (info.status === "none" ? 0.5 : 1);
    text("🔥", 0, 0, 20, "#000", 400, "center");
    ctx.restore();

    text(`${info.count} ${copy.streak}`, rx + 40, ry + rowH / 2 + 1, 13, dark ? "#ffc078" : "#e8590c", 800);

    // 7-day progress dots (7th = gift)
    const pos = info.count > 0 ? ((info.count - 1) % 7) + 1 : 0;
    const dotGap = 15;
    const dotsEnd = rx + rowW - 18;
    for (let i = 0; i < 7; i++) {
      const dx = dotsEnd - (6 - i) * dotGap;
      const dy = ry + rowH / 2;
      const filled = i < pos;
      if (i === 6) {
        ctx.globalAlpha = sEnter * (filled ? 1 : 0.5);
        text("🎁", dx, dy + 1, 14, "#000", 400, "center");
        ctx.globalAlpha = sEnter;
      } else {
        ctx.beginPath();
        ctx.arc(dx, dy, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = filled ? "#ff922b" : (dark ? "#475569" : "#e9ecef");
        ctx.fill();
      }
    }

    const hint = info.status === "active" ? copy.streakNext : copy.streakKeep;
    text(hint, w / 2, ry + rowH + 14, 11, sub, 700, "center");
    ctx.restore();
  }

  function tilePosition(tile) {
    const layout = state.layout;
    return {
      x: layout.boardX + (tile.col + tile.layer * 0.14) * layout.stepX,
      y: layout.boardY + (tile.row + tile.layer * 0.12) * layout.stepY - tile.layer * layout.size * 0.12
    };
  }

  function traySlotBounds(index) {
    const layout = state.layout;
    const y = layout.trayY + (layout.landscapePhone ? 18 : 26);
    const height = Math.min(layout.landscapePhone ? 40 : 52, layout.trayH - (y - layout.trayY) - 6);
    return {
      x: layout.trayX + index * (layout.slotW + layout.slotGap),
      y,
      width: layout.slotW,
      height
    };
  }

  function easeOut(t) {
    const n = Math.max(0, Math.min(1, t));
    return 1 - Math.pow(1 - n, 3);
  }

  // =========================================================================
  // SCREEN DRAWING: MAIN MENU
  // =========================================================================
  function drawLevelSelectScreen() {
    drawBackground();
    const w = state.width;
    const layout = state.layout;
    layout.btnMap = {};

    // Header with Back button
    roundedRect(16, 16, 92, 38, 19);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fill();
    ctx.strokeStyle = "#bce2f5";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    text(`⬅ ${copy.back}`, 62, 35, 14, "#24516b", 800, "center");
    layout.btnMap.backToMenu = { x: 16, y: 16, w: 92, h: 38 };

    text(copy.levels, w / 2, 35, 22, "#1c475e", 800, "center");

    // Coins on right
    roundedRect(w - 110, 16, 94, 38, 19);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fill();
    text(`🪙 ${state.coins}`, w - 63, 35, 15, "#e67700", 800, "center");

    // 15 levels per page (3 cols x 5 rows)
    const cols = 3;
    const rows = 5;
    const startLevel = state.levelPage * 15 + 1;
    const cardW = Math.min(92, (w - 60) / cols);
    const cardH = 74;
    const gapX = (w - 32 - cols * cardW) / (cols - 1);
    const startY = 80;

    for (let i = 0; i < 15; i++) {
      const lvlNum = startLevel + i;
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = 16 + col * (cardW + gapX);
      const y = startY + row * (cardH + 12);

      const progress = state.levelsProgress[lvlNum];
      const isUnlocked = progress !== undefined;
      const isCurrent = lvlNum === state.level;

      roundedRect(x, y, cardW, cardH, 16);
      if (isCurrent) {
        ctx.fillStyle = "#e7f5ff";
        ctx.fill();
        ctx.strokeStyle = "#339af0";
        ctx.lineWidth = 2.5;
        ctx.stroke();
      } else if (isUnlocked) {
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.strokeStyle = "#d0ebff";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      } else {
        ctx.fillStyle = "rgba(230, 238, 243, 0.7)";
        ctx.fill();
        ctx.strokeStyle = "#d8e5ec";
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      if (isUnlocked) {
        text(`${lvlNum}`, x + cardW / 2, y + 26, 20, "#194a63", 800, "center");
        // Draw 3 stars
        const stars = progress?.stars || 0;
        const starStr = (stars >= 1 ? "★" : "☆") + (stars >= 2 ? "★" : "☆") + (stars >= 3 ? "★" : "☆");
        text(starStr, x + cardW / 2, y + 54, 15, stars > 0 ? "#fcc419" : "#adb5bd", 700, "center");
        layout.btnMap[`level_${lvlNum}`] = { x, y, w: cardW, h: cardH, levelNum: lvlNum };
      } else {
        text("🔒", x + cardW / 2, y + cardH / 2, 22, "#868e96", 400, "center");
      }
    }
  }

  // =========================================================================
  // SCREEN DRAWING: THEMES STORE
  // =========================================================================
  function drawThemesScreen() {
    drawBackground();
    const w = state.width;
    const layout = state.layout;
    layout.btnMap = {};

    // Header with Back button
    roundedRect(16, 16, 92, 38, 19);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fill();
    ctx.strokeStyle = "#bce2f5";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    text(`⬅ ${copy.back}`, 62, 35, 14, "#24516b", 800, "center");
    layout.btnMap.backToMenu = { x: 16, y: 16, w: 92, h: 38 };

    text(copy.themes, w / 2, 35, 22, "#1c475e", 800, "center");

    // Coins on right
    roundedRect(w - 110, 16, 94, 38, 19);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fill();
    text(`🪙 ${state.coins}`, w - 63, 35, 15, "#e67700", 800, "center");

    const themeList = Object.values(THEMES);
    const cardW = Math.min(340, w - 32);
    const cardH = 92;
    const startY = 76;
    const gap = 14;

    themeList.forEach((theme, idx) => {
      const y = startY + idx * (cardH + gap);
      const isSelected = state.currentTheme === theme.id;
      const isUnlocked = state.unlockedThemes.includes(theme.id) || theme.price === 0;

      roundedRect((w - cardW) / 2, y, cardW, cardH, 20);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
      ctx.strokeStyle = isSelected ? theme.accentColor : "#dee2e6";
      ctx.lineWidth = isSelected ? 3 : 1.5;
      ctx.stroke();

      // Theme icon & samples
      text(theme.icon, (w - cardW) / 2 + 36, y + 36, 36, "#000", 400, "center");
      const tName = state.language === "uz" && theme.uzName ? theme.uzName : (state.language === "ru" && theme.ruName ? theme.ruName : theme.name);
      text(tName, (w - cardW) / 2 + 70, y + 26, 17, "#1c3d52", 800, "left");
      text(theme.tiles.slice(0, 5).join(" "), (w - cardW) / 2 + 70, y + 54, 16, "#000", 400, "left");

      // Action button
      const btnW = 90;
      const btnH = 38;
      const btnX = (w + cardW) / 2 - btnW - 14;
      const btnY = y + (cardH - btnH) / 2;

      roundedRect(btnX, btnY, btnW, btnH, 16);
      if (isSelected) {
        ctx.fillStyle = "#e9ecef";
        ctx.fill();
        text(copy.selected, btnX + btnW / 2, btnY + btnH / 2, 12, "#495057", 800, "center");
      } else if (isUnlocked) {
        ctx.fillStyle = "#40c057";
        ctx.fill();
        text(copy.select, btnX + btnW / 2, btnY + btnH / 2, 13, "#ffffff", 800, "center");
        layout.btnMap[`theme_select_${theme.id}`] = { x: btnX, y: btnY, w: btnW, h: btnH, themeId: theme.id };
      } else {
        ctx.fillStyle = "#fd7e14";
        ctx.fill();
        text(`${theme.price} 🪙`, btnX + btnW / 2, btnY + btnH / 2, 13, "#ffffff", 800, "center");
        layout.btnMap[`theme_buy_${theme.id}`] = { x: btnX, y: btnY, w: btnW, h: btnH, themeId: theme.id, price: theme.price };
      }
    });
  }

  // =========================================================================
  // SCREEN DRAWING: DAILY REWARDS
  // =========================================================================
  function drawDailyRewardsScreen() {
    drawBackground();
    const w = state.width;
    const h = state.height;
    const layout = state.layout;
    layout.btnMap = {};

    // Header with Back button
    roundedRect(16, 16, 92, 38, 19);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fill();
    ctx.strokeStyle = "#bce2f5";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    text(`⬅ ${copy.back}`, 62, 35, 14, "#24516b", 800, "center");
    layout.btnMap.backToMenu = { x: 16, y: 16, w: 92, h: 38 };

    text(copy.dailyTitle, w / 2, 35, 22, "#1c475e", 800, "center");

    // Coins on right
    roundedRect(w - 110, 16, 94, 38, 19);
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fill();
    text(`🪙 ${state.coins}`, w - 63, 35, 15, "#e67700", 800, "center");

    const status = getDailyRewardStatus();
    const curIndex = status.nextDayIndex;

    // Draw 7 Cards in a neat 2-row layout
    const cardW = Math.min(84, (w - 48) / 3.3);
    const cardH = 96;
    const startY = 80;

    DAILY_REWARDS_TABLE.forEach((item, idx) => {
      let x, y;
      if (idx < 3) {
        x = (w - (3 * cardW + 2 * 14)) / 2 + idx * (cardW + 14);
        y = startY;
      } else if (idx < 6) {
        x = (w - (3 * cardW + 2 * 14)) / 2 + (idx - 3) * (cardW + 14);
        y = startY + cardH + 14;
      } else {
        // Day 7 (Big card centered)
        x = (w - (cardW * 1.8)) / 2;
        y = startY + (cardH + 14) * 2;
      }
      const actualW = idx === 6 ? cardW * 1.8 : cardW;

      const isToday = idx === curIndex;
      const isClaimed = idx < curIndex && !status.canClaim;

      roundedRect(x, y, actualW, cardH, 16);
      if (isToday) {
        ctx.fillStyle = "#fff9db";
        ctx.fill();
        ctx.strokeStyle = "#fcc419";
        ctx.lineWidth = 2.5;
        ctx.stroke();
      } else {
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.strokeStyle = "#e9ecef";
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      text(`${copy.day} ${item.day}`, x + actualW / 2, y + 20, 13, "#495057", 800, "center");
      text(idx === 6 ? "🎁" : item.powerup ? "⚡" : "🪙", x + actualW / 2, y + 48, 26, "#000", 400, "center");
      text(item.label, x + actualW / 2, y + 78, 12, isToday ? "#e67700" : "#212529", 800, "center");

      if (isClaimed) {
        roundedRect(x, y, actualW, cardH, 16);
        ctx.fillStyle = "rgba(240, 243, 245, 0.75)";
        ctx.fill();
        text("✓", x + actualW / 2, y + cardH / 2, 28, "#2b8a3e", 900, "center");
      }
    });

    // Claim Button
    const btnW = Math.min(260, w - 48);
    const btnH = 50;
    const btnY = h - 85;
    roundedRect((w - btnW) / 2, btnY, btnW, btnH, 20);

    if (status.canClaim) {
      const grad = ctx.createLinearGradient(0, btnY, 0, btnY + btnH);
      grad.addColorStop(0, "#40c057");
      grad.addColorStop(1, "#2f9e44");
      ctx.fillStyle = grad;
      ctx.fill();
      text(copy.claim, w / 2, btnY + btnH / 2, 18, "#ffffff", 800, "center");
      layout.btnMap.claimDaily = { x: (w - btnW) / 2, y: btnY, w: btnW, h: btnH };
    } else {
      ctx.fillStyle = "#ced4da";
      ctx.fill();
      text(copy.claimed, w / 2, btnY + btnH / 2, 17, "#868e96", 800, "center");
    }
  }

  // =========================================================================
  // SCREEN DRAWING: GAMEPLAY & TILES
  // =========================================================================
  function drawGameHeader() {
    const w = state.width;
    const layout = state.layout;
    const headerH = layout.headerH;
    layout.btnMap = {};

    // Home button
    roundedRect(12, 10, 42, 42, 15);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.strokeStyle = "#c8e3f1";
    ctx.lineWidth = 1;
    ctx.stroke();
    text("🏠", 33, 31, 20, "#35718d", 400, "center");
    layout.btnMap.home = { x: 12, y: 10, w: 42, h: 42 };

    // Pause button
    roundedRect(60, 10, 42, 42, 15);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.strokeStyle = "#c8e3f1";
    ctx.lineWidth = 1;
    ctx.stroke();
    text(isPaused() ? "▶" : "⏸", 81, 31, 18, "#35718d", 800, "center");
    layout.btnMap.pause = { x: 60, y: 10, w: 42, h: 42 };

    // Level & Score info in center with layout silhouette name
    const levelStr = state.layoutName ? `${copy.level} ${state.level} • ${state.layoutName}` : `${copy.level} ${state.level}`;
    text(levelStr, w / 2, 22, 15, "#1f4b64", 800, "center");
    text(`${copy.score}: ${state.score}`, w / 2, 42, 13, "#547e94", 700, "center");

    // Coins counter in right corner
    roundedRect(w - 95, 12, 83, 38, 19);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.strokeStyle = "#ffe066";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    text("🪙", w - 83, 31, 16, "#000", 700, "center");
    text(`${state.coins}`, w - 50, 31, 15, "#e67700", 800, "center");
  }

  function drawTiles() {
    const sorted = state.tiles.filter(t => !t.removed).sort((a, b) => a.layer - b.layer);
    const theme = THEMES[state.currentTheme] || THEMES.fruits;

    // Detect pairs in tray for Smart Pair Glow
    const trayCounts = {};
    state.tray.forEach(t => (trayCounts[t.fruit] = (trayCounts[t.fruit] || 0) + 1));
    const pairFruits = new Set(Object.keys(trayCounts).filter(f => trayCounts[f] === 2));
    const pulse = (Math.sin(performance.now() * 0.007) + 1) * 0.5;

    for (const tile of sorted) {
      const pos = tilePosition(tile);
      const blocked = isBlocked(tile);
      const isHinted = state.hintHighlights.has(tile.id);
      const isFocused = tile.id === state.focusId && !blocked;
      const isPairGlow = !blocked && pairFruits.has(tile.fruit);
      const isGold = tile.isGolden && !blocked;

      ctx.save();
      // Drop shadow
      if (isHinted) {
        ctx.shadowColor = "rgba(255, 215, 0, 0.7)";
        ctx.shadowBlur = 14;
      } else if (isGold) {
        ctx.shadowColor = "rgba(255, 215, 0, 0.85)";
        ctx.shadowBlur = 12;
      } else if (isPairGlow) {
        ctx.shadowColor = `rgba(46, 204, 113, ${0.5 + pulse * 0.4})`;
        ctx.shadowBlur = 10 + pulse * 8;
      } else {
        ctx.shadowColor = "rgba(40, 80, 110, 0.16)";
        ctx.shadowBlur = blocked ? 2 : 6;
      }
      ctx.shadowOffsetY = blocked ? 1 : 4;

      roundedRect(pos.x, pos.y, state.layout.tileW, state.layout.tileH, Math.max(6, state.layout.size * 0.16));

      // Gradient
      const gradient = ctx.createLinearGradient(pos.x, pos.y, pos.x, pos.y + state.layout.tileH);
      if (isHinted) {
        gradient.addColorStop(0, "#fff9db");
        gradient.addColorStop(1, "#ffe066");
      } else if (isGold) {
        gradient.addColorStop(0, "#fffef0");
        gradient.addColorStop(1, "#ffeaa7");
      } else if (blocked) {
        gradient.addColorStop(0, "#dce7ed");
        gradient.addColorStop(1, "#c8d9e2");
      } else {
        gradient.addColorStop(0, "#ffffff");
        gradient.addColorStop(1, theme.tileBorder);
      }
      ctx.fillStyle = gradient;
      ctx.fill();
      ctx.restore();

      // Border
      roundedRect(pos.x + 1, pos.y + 1, state.layout.tileW - 2, state.layout.tileH - 3, Math.max(5, state.layout.size * 0.13));
      if (isHinted) {
        ctx.strokeStyle = "#f59f00";
        ctx.lineWidth = 3;
      } else if (isGold) {
        ctx.strokeStyle = "#ffd700";
        ctx.lineWidth = 2.5;
      } else if (isPairGlow) {
        ctx.strokeStyle = `rgba(39, 174, 96, ${0.6 + pulse * 0.4})`;
        ctx.lineWidth = 2.8;
      } else if (isFocused) {
        ctx.strokeStyle = "#35b985";
        ctx.lineWidth = 3;
      } else if (blocked) {
        ctx.strokeStyle = "#b8ccd6";
        ctx.lineWidth = 1.5;
      } else {
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1.5;
      }
      ctx.stroke();

      // Golden Star Badge in corner
      if (tile.isGolden) {
        text("⭐", pos.x + state.layout.tileW - 9, pos.y + 10, 10, "#000", 400, "center");
      }

      // Emoji Fruit
      ctx.globalAlpha = blocked ? 0.65 : 1;
      text(tile.fruit, pos.x + state.layout.tileW / 2, pos.y + state.layout.tileH / 2,
        Math.max(14, state.layout.size * 0.5), "#1c3e50", 500, "center");
      ctx.globalAlpha = 1;
    }
  }

  function drawTray() {
    const layout = state.layout;
    const trayY = layout.trayY;
    const topInset = layout.landscapePhone ? 5 : 9;

    roundedRect(12, trayY + 2, state.width - 24, layout.trayH - 8, 20);
    ctx.fillStyle = "rgba(255,255,255,0.88)";
    ctx.fill();
    ctx.strokeStyle = "#c8e4f1";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    text(copy.tray, 24, trayY + topInset + 7, 11, "#64869a", 800);
    text(copy.title, state.width - 24, trayY + topInset + 7, 11, "#64869a", 700, "right");

    for (let i = 0; i < 7; i++) {
      const slot = traySlotBounds(i);
      const tile = state.tray[i];
      const isFlying = tile && state.animations.some(a => a.type === "flight" && a.tile === tile);

      roundedRect(slot.x, slot.y, slot.width, slot.height, 10);
      ctx.fillStyle = "#f1f8fc";
      ctx.fill();
      ctx.strokeStyle = "#d4e8f1";
      ctx.lineWidth = 1;
      ctx.stroke();

      if (tile && !isFlying) {
        text(tile.fruit, slot.x + slot.width / 2, slot.y + slot.height / 2,
          Math.max(16, Math.min(28, layout.size * 0.48)), "#1c3e50", 500, "center");
      }
    }
  }

  function drawPowerupsBar() {
    const layout = state.layout;
    const w = state.width;
    const y = layout.powerupsY + (layout.landscapePhone ? 4 : 16);
    const items = [
      { key: "undo", icon: "↩", label: copy.undo, count: state.powerups.undo, price: 50 },
      { key: "shuffle", icon: "🔀", label: copy.shuffle, count: state.powerups.shuffle, price: 60, hasAdReward: true },
      { key: "hint", icon: "💡", label: copy.hint, count: state.powerups.hint, price: 60, hasAdReward: true },
      { key: "magic", icon: "✨", label: copy.magic, count: state.powerups.magic, price: 100 }
    ];

    const btnW = Math.min(76, (w - 40) / 4);
    const btnH = 46;
    const gap = (w - 24 - items.length * btnW) / (items.length - 1);

    items.forEach((item, idx) => {
      const x = 12 + idx * (btnW + gap);

      // Rewarded Ad mini-pill button for Shuffle and Hint
      if (item.hasAdReward) {
        const adY = y - 18;
        const adH = 16;
        roundedRect(x, adY, btnW, adH, 8);
        const adGrad = ctx.createLinearGradient(x, adY, x + btnW, adY);
        adGrad.addColorStop(0, "#ff922b");
        adGrad.addColorStop(1, "#f76707");
        ctx.fillStyle = state.adInProgress ? "#ced4da" : adGrad;
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;
        ctx.stroke();

        const adLabel = state.adInProgress ? "..." : `🎬 ${copy.watchAd}`;
        text(adLabel, x + btnW / 2, adY + 8, 8, "#ffffff", 800, "center");
        if (!state.adInProgress) {
          layout.btnMap[`ad_reward_${item.key}`] = { x, y: adY - 2, w: btnW, h: adH + 4, powerupKey: item.key };
        }
      }

      roundedRect(x, y, btnW, btnH, 16);
      ctx.fillStyle = "rgba(255,255,255,0.92)";
      ctx.fill();
      ctx.strokeStyle = "#cde3ef";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Icon & Label
      text(item.icon, x + btnW / 2, y + 16, 17, "#24516b", 700, "center");
      text(item.label, x + btnW / 2, y + 34, 10, "#547e94", 800, "center");

      // Badge (count or price)
      const badgeText = item.count > 0 ? `${item.count}` : `+${item.price}🪙`;
      const badgeW = item.count > 0 ? 20 : 38;
      roundedRect(x + btnW - badgeW + 2, y - 6, badgeW, 17, 8);
      ctx.fillStyle = item.count > 0 ? "#35b985" : "#fd7e14";
      ctx.fill();
      text(badgeText, x + btnW - badgeW / 2 + 2, y + 2.5, 9, "#ffffff", 800, "center");

      layout.btnMap[`powerup_${item.key}`] = { x, y, w: btnW, h: btnH, powerupKey: item.key };
    });
  }

  // Animated tiles and particles
  function drawAnimations() {
    for (const anim of state.animations) {
      const progress = Math.min(1, anim.elapsed / anim.duration);
      if (anim.type === "flight") {
        const slotIdx = state.tray.indexOf(anim.tile);
        if (slotIdx < 0) continue;
        const src = tilePosition(anim.tile);
        const dest = traySlotBounds(slotIdx);
        const eased = easeOut(progress);
        const curX = src.x + (dest.x - src.x) * eased;
        const curY = src.y + (dest.y - src.y) * eased;
        const curW = state.layout.tileW + (dest.width - state.layout.tileW) * eased;
        const curH = state.layout.tileH + (dest.height - state.layout.tileH) * eased;

        roundedRect(curX, curY, curW, curH, 10);
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.strokeStyle = "#bce2f5";
        ctx.lineWidth = 1.5;
        ctx.stroke();
        text(anim.tile.fruit, curX + curW / 2, curY + curH / 2, 22, "#000", 500, "center");
      } else if (anim.type === "flight_reverse") {
        const eased = easeOut(progress);
        const curX = anim.fromX + (anim.toX - anim.fromX) * eased;
        const curY = anim.fromY + (anim.toY - anim.fromY) * eased;
        roundedRect(curX - 20, curY - 24, 40, 48, 10);
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.strokeStyle = "#35b985";
        ctx.lineWidth = 2;
        ctx.stroke();
        text(anim.tile.fruit, curX, curY, 22, "#000", 500, "center");
      } else if (anim.type === "pop") {
        const scale = progress < 0.4 ? 1 + 0.4 * (progress / 0.4) : 1.4 * (1 - (progress - 0.4) / 0.6);
        ctx.save();
        ctx.globalAlpha = 1 - progress;
        anim.items.forEach(it => {
          const slot = traySlotBounds(it.slotIndex);
          ctx.translate(slot.x + slot.width / 2, slot.y + slot.height / 2);
          ctx.scale(scale, scale);
          text(it.tile.fruit, 0, 0, 26, "#000", 500, "center");
          ctx.scale(1 / scale, 1 / scale);
          ctx.translate(-(slot.x + slot.width / 2), -(slot.y + slot.height / 2));
        });
        ctx.restore();
      } else if (anim.type === "particles") {
        const sec = anim.elapsed / 1000;
        ctx.save();
        anim.particles.forEach(p => {
          const slot = traySlotBounds(p.item.slotIndex);
          const x = slot.x + slot.width / 2 + p.vx * state.layout.size * sec;
          const y = slot.y + slot.height / 2 + p.vy * state.layout.size * sec + 5 * state.layout.size * sec * sec;
          ctx.globalAlpha = 1 - progress;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(x, y, p.radius * state.layout.size, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.restore();
      } else if (anim.type === "comboText") {
        ctx.save();
        const eased = easeOut(progress);
        const y = state.layout.trayY - 22 - eased * 40;
        const scale = 1 + 0.25 * Math.sin(progress * Math.PI);
        ctx.globalAlpha = 1 - progress * 0.9;
        ctx.translate(state.width / 2, y);
        ctx.scale(scale, scale);

        // Badge pill background
        const pillW = Math.min(220, state.width - 60);
        roundedRect(-pillW / 2, -16, pillW, 32, 16);
        ctx.fillStyle = anim.multiplier >= 4 ? "#e03131" : anim.multiplier >= 3 ? "#f76707" : "#2f9e44";
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        text(`${anim.title} x${anim.multiplier} (+${anim.points})`, 0, 5, 13, "#ffffff", 800, "center");
        ctx.restore();
      } else if (anim.type === "scoreFloat") {
        ctx.save();
        const eased = easeOut(progress);
        ctx.globalAlpha = 1 - progress;
        text(`+${anim.points}`, state.width / 2, state.layout.trayY - 16 - eased * 30, 16, "#40c057", 800, "center");
        ctx.restore();
      } else if (anim.type === "goldenBonus") {
        ctx.save();
        const eased = easeOut(progress);
        ctx.globalAlpha = 1 - progress;
        text(copy.goldenBonus || "+20 🪙 Gold Bonus! ✨", anim.x, anim.y - eased * 35, 15, "#f59f00", 800, "center");
        ctx.restore();
      } else if (anim.type === "particlesRaw") {
        const sec = anim.elapsed / 1000;
        ctx.save();
        anim.particles.forEach(p => {
          const x = p.x + p.vx * state.layout.size * sec;
          const y = p.y + p.vy * state.layout.size * sec + 4 * state.layout.size * sec * sec;
          ctx.globalAlpha = 1 - progress;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(x, y, p.radius * state.layout.size, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.restore();
      } else if (anim.type === "confetti") {
        const sec = anim.elapsed / 1000;
        ctx.save();
        anim.items.forEach(c => {
          const curX = c.x + c.vx * sec * 40;
          const curY = c.y + c.vy * sec * 140;
          ctx.globalAlpha = 1 - progress * 0.7;
          ctx.fillStyle = c.color;
          ctx.save();
          ctx.translate(curX, curY);
          ctx.rotate(c.rot + c.vRot * anim.elapsed);
          ctx.fillRect(-c.w / 2, -c.h / 2, c.w, c.h);
          ctx.restore();
        });
        ctx.restore();
      }
    }
  }

  // =========================================================================
  // OVERLAYS: PAUSE, VICTORY, GAME OVER, BOOSTER MODAL
  // =========================================================================
  function drawOverlays() {
    const w = state.width;
    const h = state.height;
    const layout = state.layout;

    if (state.boosterModal) {
      // Booster Modal (Watch Ad or Buy with coins)
      ctx.fillStyle = "rgba(18, 42, 58, 0.65)";
      ctx.fillRect(0, 0, w, h);

      const boxW = Math.min(320, w - 36);
      const boxH = 260;
      const x = (w - boxW) / 2;
      const y = (h - boxH) / 2;

      roundedRect(x, y, boxW, boxH, 22);
      ctx.fillStyle = "#ffffff";
      ctx.fill();

      const modalType = state.boosterModal.type;
      const modalIcon = modalType === "hint" ? "💡" : "🔀";
      const modalName = modalType === "hint" ? copy.hint : copy.shuffle;

      text(`${modalIcon} ${modalName}`, w / 2, y + 36, 20, "#24516b", 800, "center");
      text(`Get 1 ${modalName} to keep playing!`, w / 2, y + 60, 12, "#6c757d", 600, "center");

      const btnW = boxW - 50;
      let curY = y + 80;

      // 1. Rewarded Ad Button
      const adBtnH = 48;
      roundedRect((w - btnW) / 2, curY, btnW, adBtnH, 16);
      const adGrad = ctx.createLinearGradient(0, curY, 0, curY + adBtnH);
      adGrad.addColorStop(0, "#ff922b");
      adGrad.addColorStop(1, "#f76707");
      ctx.fillStyle = state.adInProgress ? "#ced4da" : adGrad;
      ctx.fill();

      if (state.adInProgress) {
        text(copy.adLoading, w / 2, curY + adBtnH / 2 + 1, 13, "#495057", 800, "center");
      } else {
        text(`🎬  ${copy.watchAd}`, w / 2, curY + 20, 14, "#ffffff", 800, "center");
        text(`+1 Free ${modalName}`, w / 2, curY + 36, 11, "rgba(255,255,255,0.95)", 700, "center");
        layout.btnMap.booster_ad = { x: (w - btnW) / 2, y: curY, w: btnW, h: adBtnH };
      }

      curY += adBtnH + 10;

      // 2. Buy with coins
      const coinBtnH = 38;
      const canAfford = state.coins >= 60;
      roundedRect((w - btnW) / 2, curY, btnW, coinBtnH, 14);
      ctx.fillStyle = canAfford ? "#fab005" : "#e9ecef";
      ctx.fill();
      text(`🪙 60 ${copy.coins}`, w / 2, curY + coinBtnH / 2 + 1, 13, canAfford ? "#ffffff" : "#adb5bd", 800, "center");
      if (canAfford && !state.adInProgress) {
        layout.btnMap.booster_buy = { x: (w - btnW) / 2, y: curY, w: btnW, h: coinBtnH };
      }

      curY += coinBtnH + 10;

      // 3. Cancel
      const cancelBtnH = 34;
      roundedRect((w - btnW) / 2, curY, btnW, cancelBtnH, 14);
      ctx.fillStyle = "#f1f3f5";
      ctx.fill();
      text(copy.back || "Cancel", w / 2, curY + cancelBtnH / 2 + 1, 13, "#495057", 700, "center");
      layout.btnMap.booster_cancel = { x: (w - btnW) / 2, y: curY, w: btnW, h: cancelBtnH };

      return;
    }

    if (state.ended) {
      // Dim background
      ctx.fillStyle = "rgba(18, 42, 58, 0.65)";
      ctx.fillRect(0, 0, w, h);

      if (state.won) {
        const el = performance.now() - (state.winAt || 0);
        const boxW = Math.min(340, w - 36);
        const boxH = 310;
        const x = (w - boxW) / 2;
        const y = (h - boxH) / 2;
        const cx = w / 2;
        const cy = y + boxH / 2;
        const stars = state.starsEarned;

        // Confetti rain + corner cannons behind the card so text stays readable
        drawWinConfetti(el);

        // Card pops in with a bounce
        const pop = easeOutBack(el / 450);
        ctx.save();
        ctx.translate(cx, cy);
        ctx.scale(pop, pop);
        ctx.translate(-cx, -cy);
        ctx.globalAlpha = clamp01(el / 180);

        ctx.save();
        ctx.shadowColor = "rgba(0, 0, 0, 0.3)";
        ctx.shadowBlur = 24;
        ctx.shadowOffsetY = 8;
        roundedRect(x, y, boxW, boxH, 24);
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.restore();

        // Warm glow behind the header
        const glow = ctx.createRadialGradient(cx, y + 50, 0, cx, y + 50, 110);
        glow.addColorStop(0, "rgba(255, 212, 59, 0.35)");
        glow.addColorStop(1, "rgba(255, 212, 59, 0)");
        ctx.fillStyle = glow;
        ctx.fillRect(x, y, boxW, 160);

        const bob = 1 + 0.08 * Math.sin(el / 200);
        text("🎉", cx, y + 42, 42 * bob, "#000", 400, "center");

        const titleA = clamp01((el - 250) / 250);
        ctx.globalAlpha = titleA;
        text(copy.boardCleared, cx, y + 86 + (1 - titleA) * 12, 22, "#24516b", 800, "center");
        ctx.globalAlpha = 1;

        // Stars appear one by one
        const starY = y + 134;
        for (let i = 0; i < 3; i++) {
          const sx = cx + (i - 1) * 56;
          const starAt = 550 + i * 380;
          if (i < stars) {
            const p = clamp01((el - starAt) / 420);
            if (p > 0) {
              const sc = easeOutBack(p);
              ctx.save();
              ctx.translate(sx, starY);
              ctx.rotate((1 - p) * -0.7);
              ctx.scale(sc, sc);
              ctx.shadowColor = "rgba(250, 176, 5, 0.7)";
              ctx.shadowBlur = 14;
              text("★", 0, 0, 48, "#fcc419", 800, "center");
              ctx.restore();

              // sparkle burst
              const bp = (el - starAt) / 520;
              if (bp > 0 && bp < 1) {
                ctx.save();
                ctx.translate(sx, starY);
                ctx.strokeStyle = "#ffd43b";
                ctx.lineWidth = 2.5;
                ctx.lineCap = "round";
                ctx.globalAlpha = 1 - bp;
                for (let r = 0; r < 8; r++) {
                  const ang = (r / 8) * Math.PI * 2;
                  const d1 = 20 + bp * 16;
                  const d2 = d1 + 8 * (1 - bp);
                  ctx.beginPath();
                  ctx.moveTo(Math.cos(ang) * d1, Math.sin(ang) * d1);
                  ctx.lineTo(Math.cos(ang) * d2, Math.sin(ang) * d2);
                  ctx.stroke();
                }
                ctx.restore();
              }
              if (el >= starAt && (state.winStarsPlayed || 0) < i + 1) {
                state.winStarsPlayed = i + 1;
                playSound("coin");
              }
            }
          } else if (el > 300) {
            ctx.globalAlpha = 0.45;
            text("☆", sx, starY, 42, "#adb5bd", 800, "center");
            ctx.globalAlpha = 1;
          }
        }

        // Coin count-up
        const coinAt = 550 + Math.max(1, stars) * 380;
        const coinP = clamp01((el - coinAt) / 700);
        const shown = Math.round((state.winCoins || 0) * easeOut(coinP));
        ctx.globalAlpha = clamp01((el - coinAt + 200) / 250);
        text(`+${shown} 🪙  •  ${copy.score}: ${state.score}`, cx, y + 180, 15, "#e67700", 700, "center");
        ctx.globalAlpha = 1;

        // Buttons fade in (usable from ~0.9s so players are never blocked long)
        const btnW = boxW - 56;
        const btnH = 48;
        const btnA = clamp01((el - 900) / 250);
        ctx.globalAlpha = btnA;
        const slide = (1 - btnA) * 14;
        roundedRect((w - btnW) / 2, y + 200 + slide, btnW, btnH, 18);
        ctx.fillStyle = state.adInProgress ? "#ced4da" : "#40c057";
        ctx.fill();
        const nextText = state.adInProgress ? copy.adLoading : copy.nextLevel;
        text(nextText, cx, y + 224 + slide, 16, "#ffffff", 800, "center");

        roundedRect((w - btnW) / 2, y + 256 + slide, btnW, 40, 16);
        ctx.fillStyle = "#f1f3f5";
        ctx.fill();
        text(copy.home, cx, y + 276 + slide, 14, "#495057", 700, "center");
        ctx.globalAlpha = 1;
        ctx.restore();

        if (el >= 900 && !state.adInProgress) {
          layout.btnMap.nextLevel = { x: (w - btnW) / 2, y: y + 200, w: btnW, h: btnH };
          layout.btnMap.overlayHome = { x: (w - btnW) / 2, y: y + 256, w: btnW, h: 40 };
        }

      } else {
        // Lost (Tray full) - Game Over with Rewarded Extra Chance option
        const boxW = Math.min(340, w - 36);
        const boxH = Math.min(350, h - 24);
        const x = (w - boxW) / 2;
        const y = (h - boxH) / 2;

        roundedRect(x, y, boxW, boxH, 24);
        ctx.fillStyle = "#ffffff";
        ctx.fill();

        text("⚠️", w / 2, y + 36, 36, "#000", 400, "center");
        text(copy.gameOver, w / 2, y + 72, 21, "#c92a2a", 800, "center");
        text(copy.tryAgain, w / 2, y + 96, 13, "#868e96", 600, "center");

        const btnW = boxW - 56;
        let curBtnY = y + 114;

        // 1. REWARDED AD: Extra Chance (Free Revive by watching an ad)
        const adBtnH = 50;
        roundedRect((w - btnW) / 2, curBtnY, btnW, adBtnH, 18);
        const adGrad = ctx.createLinearGradient(0, curBtnY, 0, curBtnY + adBtnH);
        adGrad.addColorStop(0, "#ff922b");
        adGrad.addColorStop(1, "#f76707");
        ctx.save();
        if (!state.adInProgress) {
          ctx.shadowColor = "rgba(247, 103, 7, 0.65)";
          ctx.shadowBlur = 10 + 8 * (0.5 + 0.5 * Math.sin(performance.now() / 260));
        }
        ctx.fillStyle = state.adInProgress ? "#ced4da" : adGrad;
        ctx.fill();
        ctx.restore();

        if (state.adInProgress) {
          text(copy.adLoading, w / 2, curBtnY + adBtnH / 2 + 1, 14, "#495057", 800, "center");
        } else {
          text(`🎬  ${copy.extraChance}`, w / 2, curBtnY + 20, 15, "#ffffff", 800, "center");
          text(copy.watchAd, w / 2, curBtnY + 38, 11, "rgba(255, 255, 255, 0.95)", 700, "center");
          layout.btnMap.rewardRevive = { x: (w - btnW) / 2, y: curBtnY, w: btnW, h: adBtnH };
        }

        curBtnY += adBtnH + 8;

        // 2. COINS REVIVE BUTTON
        const coinBtnH = 40;
        roundedRect((w - btnW) / 2, curBtnY, btnW, coinBtnH, 16);
        ctx.fillStyle = state.coins >= 60 ? "#fab005" : "#e9ecef";
        ctx.fill();
        text(`${copy.revive} (60 🪙)`, w / 2, curBtnY + coinBtnH / 2 + 1, 13, state.coins >= 60 ? "#ffffff" : "#868e96", 800, "center");
        if (state.coins >= 60 && !state.adInProgress) {
          layout.btnMap.revive = { x: (w - btnW) / 2, y: curBtnY, w: btnW, h: coinBtnH };
        }

        curBtnY += coinBtnH + 8;

        // 3. RETRY (Restart level - NO ADS on restart)
        const retryBtnH = 42;
        roundedRect((w - btnW) / 2, curBtnY, btnW, retryBtnH, 16);
        ctx.fillStyle = "#339af0";
        ctx.fill();
        text(copy.tryAgain, w / 2, curBtnY + retryBtnH / 2 + 1, 14, "#ffffff", 800, "center");
        if (!state.adInProgress) {
          layout.btnMap.retry = { x: (w - btnW) / 2, y: curBtnY, w: btnW, h: retryBtnH };
        }

        curBtnY += retryBtnH + 8;

        // 4. HOME BUTTON
        const homeBtnH = 34;
        roundedRect((w - btnW) / 2, curBtnY, btnW, homeBtnH, 14);
        ctx.fillStyle = "#f1f3f5";
        ctx.fill();
        text(copy.home, w / 2, curBtnY + homeBtnH / 2 + 1, 13, "#495057", 700, "center");
        if (!state.adInProgress) {
          layout.btnMap.overlayHome = { x: (w - btnW) / 2, y: curBtnY, w: btnW, h: homeBtnH };
        }
      }
    } else if (state.manualPaused) {
      // Pause Overlay
      ctx.fillStyle = "rgba(18, 42, 58, 0.6)";
      ctx.fillRect(0, 0, w, h);

      const boxW = Math.min(310, w - 40);
      const boxH = 300;
      const x = (w - boxW) / 2;
      const y = (h - boxH) / 2;

      roundedRect(x, y, boxW, boxH, 22);
      ctx.fillStyle = "#ffffff";
      ctx.fill();

      text(copy.pause, w / 2, y + 36, 22, "#24516b", 800, "center");

      const btnW = boxW - 50;
      let curY = y + 58;

      // Resume Button
      roundedRect((w - btnW) / 2, curY, btnW, 44, 16);
      ctx.fillStyle = "#40c057";
      ctx.fill();
      text(copy.resume, w / 2, curY + 23, 16, "#ffffff", 800, "center");
      layout.btnMap.resume = { x: (w - btnW) / 2, y: curY, w: btnW, h: 44 };

      curY += 54;

      // Free Boosters Divider
      text(`🎁  ${copy.freeBoosters || "Free Boosters"}`, w / 2, curY + 6, 12, "#868e96", 700, "center");
      curY += 16;

      // Free Hint (Watch Ad)
      const bH = 36;
      roundedRect((w - btnW) / 2, curY, btnW, bH, 14);
      ctx.fillStyle = "#fff4e6";
      ctx.fill();
      ctx.strokeStyle = "#ffd8a8";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      text(`💡 +1 ${copy.hint} • ${copy.watchAd}`, w / 2, curY + bH / 2 + 1, 12, "#d9480f", 800, "center");
      if (!state.adInProgress) {
        layout.btnMap.pause_reward_hint = { x: (w - btnW) / 2, y: curY, w: btnW, h: bH };
      }

      curY += bH + 8;

      // Free Shuffle (Watch Ad)
      roundedRect((w - btnW) / 2, curY, btnW, bH, 14);
      ctx.fillStyle = "#eef2ff";
      ctx.fill();
      ctx.strokeStyle = "#c5d2fd";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      text(`🔀 +1 ${copy.shuffle} • ${copy.watchAd}`, w / 2, curY + bH / 2 + 1, 12, "#4263eb", 800, "center");
      if (!state.adInProgress) {
        layout.btnMap.pause_reward_shuffle = { x: (w - btnW) / 2, y: curY, w: btnW, h: bH };
      }

      curY += bH + 12;

      // Home
      roundedRect((w - btnW) / 2, curY, btnW, 36, 14);
      ctx.fillStyle = "#f1f3f5";
      ctx.fill();
      text(copy.home, w / 2, curY + 19, 13, "#495057", 700, "center");
      layout.btnMap.overlayHome = { x: (w - btnW) / 2, y: curY, w: btnW, h: 36 };

      curY += 44;
      // Language row in pause menu
      const pLangFlag = state.language === "uz" ? "🇺🇿 O'zbekcha" : state.language === "ru" ? "🇷🇺 Русский" : "🇬🇧 English";
      roundedRect((w - btnW) / 2, curY, btnW, 32, 12);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
      ctx.strokeStyle = "#c8e4f1";
      ctx.lineWidth = 1;
      ctx.stroke();
      text(`${copy.language || "Til"}: ${pLangFlag}`, w / 2, curY + 17, 12, "#24516b", 700, "center");
      layout.btnMap.langToggle = { x: (w - btnW) / 2, y: curY, w: btnW, h: 32 };
    }
  }

  // =========================================================================
  // MAIN DRAW DISPATCHER
  // =========================================================================
  function draw() {
    if (!state.layout) return;

    if (state.screen !== prevScreen) {
      if (prevScreen !== null) beginTransition(state.screen === "MENU" ? -1 : 1);
      prevScreen = state.screen;
      if (state.screen === "MENU") menuShownAt = performance.now();
    }

    ctx.save();
    if (state.screenShake > 0.1) {
      const sx = (Math.random() - 0.5) * state.screenShake * 2;
      const sy = (Math.random() - 0.5) * state.screenShake * 2;
      ctx.translate(sx, sy);
      state.screenShake *= 0.86;
    }

    if (state.screen === "MENU") {
      drawMenuScreen();
    } else if (state.screen === "LEVEL_SELECT") {
      drawLevelSelectScreen();
    } else if (state.screen === "THEMES") {
      drawThemesScreen();
    } else if (state.screen === "DAILY_REWARDS") {
      drawDailyRewardsScreen();
    } else if (state.screen === "GAME") {
      drawBackground(0.6);
      drawGameHeader();
      drawTiles();
      drawTray();
      drawPowerupsBar();
      drawAnimations();
      drawTutorial();
      drawOverlays();
    }

    ctx.restore();
    drawTransition(performance.now());
    syncAnimationFrame();
  }

  // RAF loop
  function updateAnimationFrame(timestamp) {
    animationFrame = null;
    if (isPaused()) {
      lastAnimationFrameTime = null;
      draw();
      return;
    }

    if (lastAnimationFrameTime !== null) {
      const elapsed = Math.max(0, timestamp - lastAnimationFrameTime);
      state.animations.forEach(anim => (anim.elapsed += elapsed));
    }
    lastAnimationFrameTime = timestamp;
    state.animations = state.animations.filter(anim => anim.elapsed < anim.duration);

    updateBGM();
    draw();
  }

  function syncAnimationFrame() {
    const needsLoop = !isPaused() && (
      state.animations.length > 0 ||
      state.screenShake > 0.1 ||
      state.musicEnabled ||
      Boolean(state.screen) ||
      transActive
    );
    if (!needsLoop) {
      if (animationFrame !== null) cancelAnimationFrame(animationFrame);
      animationFrame = null;
      lastAnimationFrameTime = null;
      return;
    }
    if (animationFrame === null) {
      animationFrame = requestAnimationFrame(updateAnimationFrame);
    }
  }

  // =========================================================================
  // INPUT HANDLING (Touch, Mouse & Keyboard)
  // =========================================================================
  function hitTestTile(x, y) {
    const sorted = state.tiles.filter(t => !t.removed).sort((a, b) => b.layer - a.layer);
    for (const tile of sorted) {
      const pos = tilePosition(tile);
      if (x >= pos.x && x <= pos.x + state.layout.tileW &&
          y >= pos.y && y <= pos.y + state.layout.tileH) {
        return tile;
      }
    }
    return null;
  }

  function handlePointer(event) {
    if (!event.isPrimary || (event.pointerType === "mouse" && event.button !== 0)) return;
    event.preventDefault();
    canvas.focus({ preventScroll: true });

    initAudioContext();

    const bounds = canvas.getBoundingClientRect();
    const x = event.clientX - bounds.left;
    const y = event.clientY - bounds.top;
    const btnMap = state.layout.btnMap || {};

    // Check UI Buttons
    for (const [key, btn] of Object.entries(btnMap)) {
      if (x >= btn.x && x <= btn.x + btn.w && y >= btn.y && y <= btn.y + btn.h) {
        playSound("tap");
        handleButtonClick(key, btn);
        return;
      }
    }

    // Gameplay Tile Selection
    if (state.screen === "GAME" && !state.ended && !isPaused()) {
      const tile = hitTestTile(x, y);
      if (tile) {
        state.focusId = tile.id;
        if (isBlocked(tile)) {
          playSound("error");
          showMessage(copy.choose);
          draw();
          return;
        }
        selectTile(tile);
      }
    }
  }

  function handleButtonClick(key, btn) {
    // Top audio controls
    if (key === "soundToggle") {
      state.soundEnabled = !state.soundEnabled;
      saveState();
      draw();
      return;
    }
    if (key === "musicToggle") {
      state.musicEnabled = !state.musicEnabled;
      saveState();
      draw();
      return;
    }
    if (key === "langToggle") {
      const langs = ["uz", "en", "ru"];
      const nextIdx = (langs.indexOf(state.language) + 1) % langs.length;
      setLanguage(langs[nextIdx]);
      return;
    }

    // Navigation
    if (key === "play") {
      startLevel(state.level);
      return;
    }
    if (key === "levels") {
      state.screen = "LEVEL_SELECT";
      draw();
      return;
    }
    if (key === "themes") {
      state.screen = "THEMES";
      draw();
      return;
    }
    if (key === "rewards") {
      state.screen = "DAILY_REWARDS";
      draw();
      return;
    }
    if (key === "backToMenu" || key === "home" || key === "overlayHome") {
      state.screen = "MENU";
      state.manualPaused = false;
      draw();
      return;
    }

    // Level selection
    if (key.startsWith("level_")) {
      startLevel(btn.levelNum);
      return;
    }

    // Themes
    if (key.startsWith("theme_select_")) {
      state.currentTheme = btn.themeId;
      saveState();
      draw();
      return;
    }
    if (key.startsWith("theme_buy_")) {
      if (state.coins >= btn.price) {
        state.coins -= btn.price;
        state.unlockedThemes.push(btn.themeId);
        state.currentTheme = btn.themeId;
        playSound("coin");
        saveState();
        draw();
      } else {
        playSound("error");
        showMessage(copy.needCoins);
      }
      return;
    }

    // Daily claim
    if (key === "claimDaily") {
      claimDailyReward();
      draw();
      return;
    }

    // In-game controls
    if (key === "pause") {
      state.manualPaused = !state.manualPaused;
      notifyPlatform(state.manualPaused ? "level_paused" : "level_resumed");
      draw();
      return;
    }
    if (key === "resume") {
      state.manualPaused = false;
      notifyPlatform("level_resumed");
      draw();
      return;
    }
    if (key === "nextLevel") {
      if (state.adInProgress) return;
      const nextLvl = state.level + 1;
      if (state.levelsCompletedSinceAd >= 2) {
        showInterstitialAd("level_completed", () => {
          state.levelsCompletedSinceAd = 0;
          saveState();
          state.level = nextLvl;
          startLevel(state.level);
        });
      } else {
        state.level = nextLvl;
        startLevel(state.level);
      }
      return;
    }
    if (key === "retry") {
      if (state.adInProgress) return;
      // Every 2nd retry shows an interstitial (Bridge still enforces its own cooldown)
      state.lossesSinceAd = (state.lossesSinceAd || 0) + 1;
      if (state.lossesSinceAd >= 2) {
        showInterstitialAd("game_over", () => {
          state.lossesSinceAd = 0;
          startLevel(state.level);
        });
        return;
      }
      startLevel(state.level);
      return;
    }
    if (key === "revive") {
      if (state.adInProgress) return;
      reviveGame();
      return;
    }
    if (key === "rewardRevive") {
      if (state.adInProgress) return;
      showRewardedAd("revive", () => {
        state.tray.splice(0, Math.min(3, state.tray.length));
        state.ended = false;
        state.won = false;
        playSound("powerup");
        showMessage(copy.rewardReceivedChance);
        saveState();
        draw();
      });
      return;
    }

    // Free Boosters via Rewarded Ads
    if (key === "ad_reward_shuffle" || key === "pause_reward_shuffle") {
      if (state.adInProgress) return;
      showRewardedAd("shuffle", () => {
        state.powerups.shuffle += 1;
        playSound("coin");
        showMessage(copy.rewardReceivedShuffle);
        saveState();
        draw();
      });
      return;
    }
    if (key === "ad_reward_hint" || key === "pause_reward_hint") {
      if (state.adInProgress) return;
      showRewardedAd("hint", () => {
        state.powerups.hint += 1;
        playSound("coin");
        showMessage(copy.rewardReceivedHint);
        saveState();
        draw();
      });
      return;
    }

    // Booster Modal actions
    if (key === "booster_ad") {
      if (state.adInProgress) return;
      const boosterType = state.boosterModal?.type || "hint";
      state.boosterModal = null;
      draw();
      showRewardedAd(boosterType, () => {
        state.powerups[boosterType] += 1;
        playSound("coin");
        showMessage(boosterType === "hint" ? copy.rewardReceivedHint : copy.rewardReceivedShuffle);
        saveState();
        draw();
      });
      return;
    }
    if (key === "booster_buy") {
      if (state.adInProgress) return;
      const boosterType = state.boosterModal?.type || "hint";
      if (state.coins >= 60) {
        state.coins -= 60;
        state.powerups[boosterType] += 1;
        playSound("coin");
        showMessage(`+1 ${boosterType === "hint" ? copy.hint : copy.shuffle}!`);
        saveState();
      } else {
        playSound("error");
        showMessage(copy.needCoins);
      }
      state.boosterModal = null;
      draw();
      return;
    }
    if (key === "booster_cancel") {
      state.boosterModal = null;
      draw();
      return;
    }

    // Powerups
    if (key === "powerup_undo") {
      useUndo();
      return;
    }
    if (key === "powerup_shuffle") {
      useShuffle();
      return;
    }
    if (key === "powerup_hint") {
      useHint();
      return;
    }
    if (key === "powerup_magic") {
      useMagic();
      return;
    }
  }

  function startLevel(lvlNum) {
    if (state.screen === "GAME") beginTransition(1);
    if (lvlNum > 1) state.tutorialDone = true;
    state.level = lvlNum;
    state.screen = "GAME";
    state.manualPaused = false;
    state.boosterModal = null;
    makeBoardForLevel(lvlNum);
    const streakGrew = touchStreak();
    saveState();
    if (streakGrew && state.streak.count > 1) {
      showMessage(`🔥 ${state.streak.count} ${copy.streak}!`);
    }
    notifyPlatform("level_started");
    draw();
  }

  // Keyboard navigation
  function handleKeyDown(event) {
    if (event.key === "Escape") {
      event.preventDefault();
      if (state.screen === "GAME") {
        if (!state.ended) {
          state.manualPaused = !state.manualPaused;
          notifyPlatform(state.manualPaused ? "level_paused" : "level_resumed");
          draw();
        }
      } else {
        state.screen = "MENU";
        draw();
      }
      return;
    }

    if (event.key.toLowerCase() === "r" && state.screen === "GAME") {
      event.preventDefault();
      startLevel(state.level);
      return;
    }

    if (state.screen === "GAME" && !state.ended && !isPaused()) {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        const tile = state.tiles.find(t => t.id === state.focusId);
        if (tile && !isBlocked(tile)) selectTile(tile);
      }
    }
  }

  // =========================================================================
  // BOOTSTRAP INITIALIZATION
  // =========================================================================
  function start(dependencies) {
    window.fruitTileDependencies = dependencies;
    resize();
    window.addEventListener("resize", resize, { passive: true });
    window.addEventListener("orientationchange", resize, { passive: true });
    canvas.addEventListener("pointerdown", handlePointer);
    canvas.addEventListener("contextmenu", e => e.preventDefault());
    window.addEventListener("keydown", handleKeyDown);

    // Initial check for daily rewards
    if (getDailyRewardStatus().canClaim) {
      showMessage("🎁 Daily Reward Ready!");
    }

    draw();

    return {
      setAudioEnabled(enabled) {
        state.platformAudioEnabled = enabled;
        draw();
      },
      setPlatformPaused(paused) {
        state.platformPaused = paused;
        draw();
      },
      setAdPaused(paused) {
        state.adPaused = paused;
        draw();
      },
      setDocumentPaused(paused) {
        state.documentPaused = paused;
        draw();
      },
      showMessage(msg) {
        showMessage(msg);
        draw();
      },
      _getState() {
        return state;
      },
      _handleAction(key, btn) {
        handleButtonClick(key, btn || {});
      },
      _finishBoard(won) {
        finishBoard(won);
      }
    };
  }

  window.FruitTileGame = { start };
})();
