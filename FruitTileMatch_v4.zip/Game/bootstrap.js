(() => {
  "use strict";

  const progressKey = "fruit_tile_match_progress";
  const loading = document.getElementById("loading");
  const loadingMessage = document.getElementById("loading-message");
  const retryButton = document.getElementById("retry");
  let starting = false;

  function showLoadingMessage(message, canRetry) {
    loading.hidden = false;
    loadingMessage.textContent = message;
    retryButton.hidden = !canRetry;
  }

  function showWarning(message) {
    console.warn(`[Fruit Tile Match] ${message}`);
  }

  function injectGame(dependencies) {
    window.fruitTileDependencies = dependencies;
    const script = document.createElement("script");
    script.src = "./game.js";
    script.onload = () => {
      if (!window.FruitTileGame) {
        showLoadingMessage("The game could not start. Please reload the page.", true);
        showWarning("game.js loaded without registering the game.");
        return;
      }

      loading.hidden = true;
      const game = window.FruitTileGame.start(dependencies);
      window.fruitTileInstance = game;
      if (dependencies.bridge) {
        const bridge = dependencies.bridge;
        let platformPaused = bridge.platform.isPaused === true;
        let interstitialOpened = bridge.advertisement?.interstitialState === "opened";
        let rewardedOpened = bridge.advertisement?.rewardedState === "opened";
        let adPaused = interstitialOpened || rewardedOpened;
        let audioEnabled = bridge.platform.isAudioEnabled !== false;

        function updateAdState(interstitialState, rewardedState) {
          if (interstitialState) interstitialOpened = interstitialState === "opened";
          if (rewardedState) rewardedOpened = rewardedState === "opened";
          const nextAdPaused = interstitialOpened || rewardedOpened;
          if (nextAdPaused === adPaused) return;
          adPaused = nextAdPaused;
          game.setAdPaused(adPaused);
          if (adPaused) {
            game.setAudioEnabled(false);
          } else {
            audioEnabled = bridge.platform.isAudioEnabled !== false;
            game.setAudioEnabled(audioEnabled);
          }
        }

        game.setPlatformPaused(platformPaused);
        game.setAdPaused(adPaused);
        game.setAudioEnabled(adPaused ? false : audioEnabled);
        dependencies.bridge.platform.on(
          bridge.EVENT_NAME.PAUSE_STATE_CHANGED,
          isPaused => {
            const nextPaused = Boolean(isPaused);
            if (nextPaused === platformPaused) return;
            platformPaused = nextPaused;
            game.setPlatformPaused(platformPaused);
          }
        );
        bridge.platform.on(
          bridge.EVENT_NAME.AUDIO_STATE_CHANGED,
          isEnabled => {
            const nextEnabled = Boolean(isEnabled);
            if (nextEnabled === audioEnabled) return;
            audioEnabled = nextEnabled;
            if (!adPaused) game.setAudioEnabled(audioEnabled);
          }
        );
        bridge.advertisement.on(
          bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED,
          state => updateAdState(state, null)
        );
        bridge.advertisement.on(
          bridge.EVENT_NAME.REWARDED_STATE_CHANGED,
          state => updateAdState(null, state)
        );
        document.addEventListener("visibilitychange", () => {
          game.setDocumentPaused(document.visibilityState !== "visible");
        });

        bridge.platform.sendMessage("game_ready").catch(error => {
          showWarning(`Could not send game_ready to Playgama Bridge: ${error.message || error}`);
          game.showMessage("Game ready, but platform notification failed.");
        });
      }
    };
    script.onerror = () => {
      showLoadingMessage("The game files could not be loaded. Check the game package.", true);
      showWarning("Failed to load game.js.");
    };
    document.body.appendChild(script);
  }

  async function start() {
    if (starting) return;
    starting = true;
    retryButton.hidden = true;
    showLoadingMessage("Getting the game ready...", false);

    // Helper for local storage progress fallback
    function getLocalProgress() {
      try {
        const raw = localStorage.getItem(progressKey);
        return raw ? JSON.parse(raw) : null;
      } catch (e) {
        return null;
      }
    }

    function saveLocalProgress(data) {
      try {
        localStorage.setItem(progressKey, JSON.stringify(data));
      } catch (e) {
        showWarning("Could not save to localStorage: " + e.message);
      }
    }

    if (!window.bridge) {
      showWarning("Playgama Bridge is unavailable. Starting with localStorage persistence.");
      const progress = getLocalProgress();
      injectGame({
        bridge: null,
        language: navigator.language ? navigator.language.slice(0, 2) : "en",
        progress: progress,
        saveProgress: async data => {
          saveLocalProgress(data);
        }
      });
      starting = false;
      return;
    }

    try {
      if (!window.bridge.isInitialized && typeof window.bridge.initialize === "function") {
        await window.bridge.initialize();
      }
      const language = window.bridge.platform.language || "en";
      let progress = null;
      try {
        const values = await window.bridge.storage.get([progressKey]);
        if (values[0] != null) {
          progress = typeof values[0] === "string" ? JSON.parse(values[0]) : values[0];
        } else {
          progress = getLocalProgress();
        }
      } catch (error) {
        showWarning(`Could not load saved progress from Playgama Bridge: ${error.message || error}`);
        progress = getLocalProgress();
      }

      injectGame({
        bridge: window.bridge,
        language,
        progress,
        saveProgress: async data => {
          saveLocalProgress(data);
          try {
            await window.bridge.storage.set([progressKey], [JSON.stringify(data)]);
          } catch (e) {
            showWarning("Bridge storage save failed, saved locally: " + e.message);
          }
        }
      });
    } catch (error) {
      showWarning(`Playgama Bridge could not initialize: ${error.message || error}. Falling back to offline.`);
      const progress = getLocalProgress();
      injectGame({
        bridge: null,
        language: "en",
        progress: progress,
        saveProgress: async data => {
          saveLocalProgress(data);
        }
      });
    } finally {
      starting = false;
    }
  }

  retryButton.addEventListener("click", start);
  start();
})();
