# Fruit Tile Match

A browser-based HTML5 match-three tile puzzle for desktop, tablet, and mobile.
The game and the Playgama Bridge SDK are included in this folder; it does not
need a build step, backend, account, or game assets hosted elsewhere.

## Run locally

Open `index.html` in a browser to try the game in offline mode. Offline mode
does not save progress or show ads. For SDK testing, serve this folder from a
local HTTP server and open its URL; Playgama Bridge then initializes with its
development/mock platform.

## Playgama package

Upload the folder contents together, keeping `index.html`,
`playgama-bridge-config.json`, and `playgama-bridge.js` side by side. The
official Playgama Bridge JavaScript Core SDK is version 2.4.2 and is included
locally under its LGPL-3.0-or-later license. The accompanying license texts are
included in `PLAYGAMA-BRIDGE-LICENSE` and `PLAYGAMA-BRIDGE-GPL-LICENSE`.

The game initializes Bridge before loading gameplay, loads and saves progress
through Bridge Storage, handles host pause/audio events, reports `game_ready`,
and requests interstitials at level-complete and game-over screens. Bridge
controls whether an ad is actually displayed and enforces its own ad timing.
The project does not create rewarded-ad buttons or substitute ads.

Before publishing, run the Playgama submission checks for the selected target
platforms and confirm that the configured interstitial placements are accepted
for those platforms. Platform approval and live ad delivery cannot be tested
from a local browser.

## Controls

- Mouse: left-click a free tile or an on-screen control.
- Touch: tap a free tile or an on-screen control.
- Keyboard: arrow keys move the tile focus, Enter/Space selects, Escape
  pauses or resumes, and R starts a new game.
